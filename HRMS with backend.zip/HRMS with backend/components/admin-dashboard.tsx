"use client"

import { useState } from "react"
import TopNavbar from "./top-navbar"
import EmployeeGridSection from "./employee-grid-section"
import AdminAttendanceSection from "./admin-attendance-section"
import AdminProfileSection from "./admin-profile-section"
import AdminTimeOffSection from "./admin-timeoff-section"

interface AdminDashboardProps {
  onLogout: () => void
}

type NavSection = "employees" | "attendance" | "time off" | "my profile"

export default function AdminDashboard({ onLogout }: AdminDashboardProps) {
  const [activeNav, setActiveNav] = useState<NavSection>("employees")

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground selection:bg-primary/30">
      <TopNavbar role="admin" activeNav={activeNav} onNavChange={setActiveNav} onLogout={onLogout} />

      <main className="flex-1 max-w-7xl mx-auto w-full px-8 py-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
        <div className="glass-card rounded-3xl border border-border/40 bg-card/30 backdrop-blur-sm p-8 shadow-2xl">
          {activeNav === "employees" && <EmployeeGridSection role="admin" />}
          {activeNav === "attendance" && <AdminAttendanceSection />}
          {activeNav === "time off" && <AdminTimeOffSection />}
          {activeNav === "my profile" && <AdminProfileSection />}
        </div>
      </main>
    </div>
  )
}
