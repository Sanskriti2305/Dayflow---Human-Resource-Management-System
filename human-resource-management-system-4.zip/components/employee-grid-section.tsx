"use client"

import type React from "react"

import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { useState } from "react"
import { Search, Plus, Plane } from "lucide-react"

interface Employee {
  id: number
  name: string
  avatar: string
  status: "present" | "absent" | "leave"
  isCheckedIn: boolean
  checkInTime?: string
  checkOutTime?: string
}

interface EmployeeGridSectionProps {
  role?: "employee" | "admin"
}

export default function EmployeeGridSection({ role = "employee" }: EmployeeGridSectionProps) {
  const [employees, setEmployees] = useState<Employee[]>([
    { id: 1, name: "John Doe", avatar: "JD", status: "present", isCheckedIn: false },
    { id: 2, name: "Jane Smith", avatar: "JS", status: "present", isCheckedIn: false },
    { id: 3, name: "Mike Johnson", avatar: "MJ", status: "leave", isCheckedIn: false },
    { id: 4, name: "Sarah Williams", avatar: "SW", status: "present", isCheckedIn: false },
    { id: 5, name: "Tom Brown", avatar: "TB", status: "absent", isCheckedIn: false },
    { id: 6, name: "Emily Davis", avatar: "ED", status: "present", isCheckedIn: false },
    { id: 7, name: "Robert Miller", avatar: "RM", status: "present", isCheckedIn: false },
    { id: 8, name: "Lisa Anderson", avatar: "LA", status: "absent", isCheckedIn: false },
    { id: 9, name: "David Taylor", avatar: "DT", status: "present", isCheckedIn: false },
  ])

  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null)

  const handleCheckIn = (employeeId: number, e: React.MouseEvent) => {
    e.stopPropagation()
    const now = new Date()
    const timeString = now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })

    setEmployees((prev) =>
      prev.map((emp) =>
        emp.id === employeeId
          ? {
              ...emp,
              isCheckedIn: true,
              checkInTime: timeString,
              checkOutTime: undefined,
            }
          : emp,
      ),
    )
  }

  const handleCheckOut = (employeeId: number, e: React.MouseEvent) => {
    e.stopPropagation()
    const now = new Date()
    const timeString = now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })

    setEmployees((prev) =>
      prev.map((emp) =>
        emp.id === employeeId
          ? {
              ...emp,
              isCheckedIn: false,
              checkOutTime: timeString,
            }
          : emp,
      ),
    )
  }

  const statusColors = {
    present: "bg-green-500",
    absent: "bg-red-500",
    leave: "bg-yellow-500",
  }

  return (
    <div className="space-y-6">
      {role === "admin" && (
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          {/* Search Bar */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Search employees..."
              className="pl-10 bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
            />
          </div>
          {/* NEW Button */}
          <Button className="bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-semibold">
            <Plus className="w-4 h-4 mr-2" />
            NEW
          </Button>
        </div>
      )}

      {/* Employee Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {employees.map((employee) => (
          <Card
            key={employee.id}
            className="bg-white border border-gray-200 cursor-pointer hover:border-gray-400 transition relative"
            onClick={() => setSelectedEmployee(employee)}
          >
            <div className="absolute top-3 right-3 z-10" onClick={(e) => e.stopPropagation()}>
              {employee.status === "present" && (
                <Popover>
                  <PopoverTrigger asChild>
                    <button
                      className={`w-3 h-3 ${employee.isCheckedIn ? "bg-green-500" : "bg-red-500"} rounded-full border-2 border-white shadow-sm cursor-pointer hover:scale-110 transition-transform`}
                      aria-label={employee.isCheckedIn ? "Check out" : "Check in"}
                    />
                  </PopoverTrigger>
                  <PopoverContent className="w-48 p-3" align="end">
                    <div className="space-y-3">
                      <div className="text-sm font-semibold text-slate-900">Attendance</div>
                      {employee.isCheckedIn ? (
                        <>
                          <div className="text-xs text-slate-600">
                            Checked in at: <span className="font-medium">{employee.checkInTime}</span>
                          </div>
                          <Button
                            size="sm"
                            className="w-full bg-red-500 hover:bg-red-600 text-white"
                            onClick={(e) => handleCheckOut(employee.id, e)}
                          >
                            Check Out
                          </Button>
                        </>
                      ) : (
                        <>
                          {employee.checkOutTime && (
                            <div className="text-xs text-slate-600">
                              Last check out: <span className="font-medium">{employee.checkOutTime}</span>
                            </div>
                          )}
                          <Button
                            size="sm"
                            className="w-full bg-green-500 hover:bg-green-600 text-white"
                            onClick={(e) => handleCheckIn(employee.id, e)}
                          >
                            Check In
                          </Button>
                        </>
                      )}
                    </div>
                  </PopoverContent>
                </Popover>
              )}
              {employee.status === "leave" && (
                <div className="w-5 h-5 bg-cyan-500 rounded-full flex items-center justify-center border-2 border-white shadow-sm">
                  <Plane className="w-2.5 h-2.5 text-white fill-white" />
                </div>
              )}
              {employee.status === "absent" && (
                <div className="w-3 h-3 bg-yellow-500 rounded-full border-2 border-white shadow-sm" />
              )}
            </div>
            <CardContent className="p-6">
              <div className="flex flex-col items-center">
                <div className="relative mb-3">
                  <div className="w-20 h-20 bg-gray-200 rounded flex items-center justify-center">
                    <span className="text-gray-600 font-semibold text-lg">{employee.avatar}</span>
                  </div>
                </div>
                {/* Employee Name */}
                <h3 className="text-gray-900 font-medium text-center">{employee.name}</h3>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Employee Detail Modal - VIEW ONLY */}
      {selectedEmployee && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <Card className="bg-white border border-gray-200 w-full max-w-md">
            <CardContent className="p-6 space-y-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold text-gray-900">{selectedEmployee.name}</h3>
                <button onClick={() => setSelectedEmployee(null)} className="text-gray-400 hover:text-gray-900">
                  ✕
                </button>
              </div>
              <div className="space-y-2 text-sm text-gray-700">
                <p>
                  <span className="font-semibold">Employee ID:</span> EMP-
                  {selectedEmployee.id.toString().padStart(3, "0")}
                </p>
                <p>
                  <span className="font-semibold">Department:</span> Engineering
                </p>
                <p>
                  <span className="font-semibold">Position:</span> Senior Developer
                </p>
                <p>
                  <span className="font-semibold">Status:</span>{" "}
                  <span
                    className={`font-semibold capitalize ${selectedEmployee.status === "present" ? "text-green-600" : selectedEmployee.status === "leave" ? "text-yellow-600" : "text-red-600"}`}
                  >
                    {selectedEmployee.status}
                  </span>
                </p>
                {selectedEmployee.isCheckedIn && (
                  <p>
                    <span className="font-semibold">Check In Time:</span>{" "}
                    <span className="font-medium">{selectedEmployee.checkInTime}</span>
                  </p>
                )}
                {selectedEmployee.checkOutTime && (
                  <p>
                    <span className="font-semibold">Check Out Time:</span>{" "}
                    <span className="font-medium">{selectedEmployee.checkOutTime}</span>
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
