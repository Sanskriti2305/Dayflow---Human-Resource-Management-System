"use client"

import { useEffect, useState } from "react"
import { supabase } from "@/lib/supabaseClient"
import { Button } from "@/components/ui/button"
import { Plus, X } from "lucide-react"

export default function EmployeeTimeOffSection() {
  const [showModal, setShowModal] = useState(false)
  const [loading, setLoading] = useState(false)

  const [formData, setFormData] = useState({
    reason: "Paid Time Off",
    startDate: "",
    endDate: "",
  })

  const [leaveRequests, setLeaveRequests] = useState<any[]>([])
  const [userProfileId, setUserProfileId] = useState<string | null>(null)

  // 🔑 STEP 1: get users.id ONCE
  useEffect(() => {
    init()
  }, [])

  const init = async () => {
    const { data: auth } = await supabase.auth.getUser()
    if (!auth.user) return

    const { data: profile, error } = await supabase
      .from("users")
      .select("id")
      .eq("auth_id", auth.user.id)
      .single()

    if (error) {
      alert("User profile missing")
      return
    }

    setUserProfileId(profile.id)
    fetchMyRequests(profile.id)
  }

  // 🔄 STEP 2: fetch ONLY my leave
  const fetchMyRequests = async (profileId: string) => {
    const { data, error } = await supabase
      .from("leave_requests")
      .select("id, start_date, end_date, reason , status, reason")
      .eq("user_id", profileId)
      .order("created_at", { ascending: false })

    if (error) {
      alert(error.message)
      return
    }

    setLeaveRequests(data)
  }

  // 🟢 STEP 3: submit leave (WORKING)
  const handleSubmit = async () => {
    if (!userProfileId) {
      alert("User not ready")
      return
    }

    if (!formData.startDate || !formData.endDate) {
      alert("Select dates")
      return
    }

    setLoading(true)

    const { error } = await supabase.from("leave_requests").insert({
      user_id: userProfileId,
      start_date: formData.startDate,
      end_date: formData.endDate,
      reason: formData.reason,
      status: "pending",
    })

    setLoading(false)

    if (error) {
      alert(error.message)
      return
    }

    setShowModal(false)
    setFormData({ reason: "Paid Time Off", startDate: "", endDate: "" })
    fetchMyRequests(userProfileId)
  }

  const statusColors: any = {
    pending: "bg-yellow-900 text-yellow-300",
    approved: "bg-green-900 text-green-300",
    rejected: "bg-red-900 text-red-300",
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between">
        <h2 className="text-2xl font-semibold text-white">My Leave</h2>
        <Button onClick={() => setShowModal(true)} className="bg-purple-600">
          <Plus className="w-4 h-4 mr-2" /> New
        </Button>
      </div>

      <div className="border border-slate-600 rounded-lg bg-slate-950">
        <table className="w-full text-sm">
          <thead className="bg-slate-900">
            <tr>
              <th className="p-3 text-left text-white">From</th>
              <th className="p-3 text-left text-white">To</th>
              <th className="p-3 text-left text-white">Type</th>
              <th className="p-3 text-left text-white">Status</th>
            </tr>
          </thead>
          <tbody>
            {leaveRequests.length === 0 && (
              <tr>
                <td colSpan={4} className="p-6 text-center text-slate-400">
                  No leave requests
                </td>
              </tr>
            )}

            {leaveRequests.map((l) => (
              <tr key={l.id} className="border-t border-slate-700">
                <td className="p-3 text-slate-300">{l.start_date}</td>
                <td className="p-3 text-slate-300">{l.end_date}</td>
                <td className="p-3 text-cyan-400">{l.reason}</td>
                <td className="p-3">
                  <span className={`px-3 py-1 rounded text-xs ${statusColors[l.status]}`}>
                    {l.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex justify-center items-center">
          <div className="bg-slate-900 p-6 rounded w-full max-w-md">
            <div className="flex justify-between mb-4">
              <h3 className="text-white">Request Leave</h3>
              <button onClick={() => setShowModal(false)}>
                <X className="text-slate-400" />
              </button>
            </div>

            <select
              value={formData.reason}
              onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
              className="w-full mb-3 bg-slate-800 p-2 text-white rounded"
            >
              <option>Paid Time Off</option>
              <option>Sick Leave</option>
              <option>Unpaid Leave</option>
            </select>

            <div className="flex gap-2 mb-4">
              <input
                type="date"
                value={formData.startDate}
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                className="flex-1 bg-slate-800 p-2 text-white rounded"
              />
              <input
                type="date"
                value={formData.endDate}
                onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                className="flex-1 bg-slate-800 p-2 text-white rounded"
              />
            </div>

            <Button
              disabled={loading}
              onClick={handleSubmit}
              className="w-full bg-purple-600"
            >
              {loading ? "Submitting..." : "Submit"}
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
