"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, Clock } from "lucide-react"

export default function AttendanceSection() {
  const attendanceData = [
    { date: "Jan 16, 2025", status: "Present", checkIn: "09:00 AM", checkOut: "06:00 PM" },
    { date: "Jan 15, 2025", status: "Present", checkIn: "08:55 AM", checkOut: "06:05 PM" },
    { date: "Jan 14, 2025", status: "Half-day", checkIn: "09:10 AM", checkOut: "01:00 PM" },
    { date: "Jan 13, 2025", status: "Present", checkIn: "09:00 AM", checkOut: "06:00 PM" },
    { date: "Jan 10, 2025", status: "Leave", checkIn: "-", checkOut: "-" },
    { date: "Jan 09, 2025", status: "Absent", checkIn: "-", checkOut: "-" },
  ]

  const statusColors = {
    Present: "bg-green-900 text-green-200",
    "Half-day": "bg-yellow-900 text-yellow-200",
    Leave: "bg-blue-900 text-blue-200",
    Absent: "bg-red-900 text-red-200",
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-white">Attendance</h2>
        <Button className="bg-cyan-600 hover:bg-cyan-700">Check In</Button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-300">Present Days</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-400">18</div>
            <p className="text-xs text-slate-400 mt-1">This month</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-300">Absent Days</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-400">1</div>
            <p className="text-xs text-slate-400 mt-1">This month</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-300">Attendance Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-cyan-400">94%</div>
            <p className="text-xs text-slate-400 mt-1">This month</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-300">Status Today</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold text-green-400">Checked In</div>
            <p className="text-xs text-slate-400 mt-1">09:00 AM</p>
          </CardContent>
        </Card>
      </div>

      {/* Attendance Records */}
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Attendance Records
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="text-left py-3 px-4 text-slate-300 font-semibold">Date</th>
                  <th className="text-left py-3 px-4 text-slate-300 font-semibold">Status</th>
                  <th className="text-left py-3 px-4 text-slate-300 font-semibold">Check In</th>
                  <th className="text-left py-3 px-4 text-slate-300 font-semibold">Check Out</th>
                </tr>
              </thead>
              <tbody>
                {attendanceData.map((record) => (
                  <tr key={record.date} className="border-b border-slate-800 hover:bg-slate-800 transition">
                    <td className="py-3 px-4 text-slate-300">{record.date}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold ${statusColors[record.status as keyof typeof statusColors]}`}
                      >
                        {record.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-300 flex items-center gap-2">
                      <Clock className="w-4 h-4 text-slate-400" />
                      {record.checkIn}
                    </td>
                    <td className="py-3 px-4 text-slate-300">{record.checkOut}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
