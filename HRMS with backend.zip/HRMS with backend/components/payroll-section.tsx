"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { DollarSign, Download } from "lucide-react"

export default function PayrollSection() {
  const salaryStructure = [
    { label: "Base Salary", value: "$5,000.00" },
    { label: "HRA", value: "$1,000.00" },
    { label: "Dearness Allowance", value: "$500.00" },
    { label: "Gross Salary", value: "$6,500.00", isTotal: true },
  ]

  const deductions = [
    { label: "Income Tax", value: "$650.00" },
    { label: "Provident Fund", value: "$500.00" },
    { label: "Total Deductions", value: "$1,150.00", isTotal: true },
  ]

  const payslips = [
    { month: "December 2024", date: "Jan 5, 2025", netPay: "$5,350.00" },
    { month: "November 2024", date: "Dec 5, 2024", netPay: "$5,350.00" },
    { month: "October 2024", date: "Nov 5, 2024", netPay: "$5,350.00" },
  ]

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-white">Payroll & Salary</h2>

      {/* Net Salary */}
      <Card className="bg-gradient-to-r from-cyan-900 to-cyan-800 border-cyan-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-white flex items-center gap-2">
            <DollarSign className="w-6 h-6" />
            Current Net Salary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-4xl font-bold text-cyan-100">$5,350.00</div>
          <p className="text-cyan-200 text-sm mt-1">Monthly take-home pay</p>
        </CardContent>
      </Card>

      {/* Salary Structure */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-slate-900 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Salary Structure</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {salaryStructure.map((item, idx) => (
                <div
                  key={idx}
                  className={`flex justify-between items-center p-3 rounded-lg ${
                    item.isTotal ? "bg-cyan-900 border border-cyan-700" : "bg-slate-800"
                  }`}
                >
                  <span className={item.isTotal ? "text-cyan-100 font-semibold" : "text-slate-300"}>{item.label}</span>
                  <span className={item.isTotal ? "text-cyan-100 font-bold" : "text-slate-200 font-semibold"}>
                    {item.value}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Deductions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {deductions.map((item, idx) => (
                <div
                  key={idx}
                  className={`flex justify-between items-center p-3 rounded-lg ${
                    item.isTotal ? "bg-red-900 border border-red-700" : "bg-slate-800"
                  }`}
                >
                  <span className={item.isTotal ? "text-red-100 font-semibold" : "text-slate-300"}>{item.label}</span>
                  <span className={item.isTotal ? "text-red-100 font-bold" : "text-slate-200 font-semibold"}>
                    {item.value}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payslips */}
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Recent Payslips</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {payslips.map((payslip, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-4 bg-slate-800 rounded-lg hover:bg-slate-700 transition"
              >
                <div>
                  <p className="font-semibold text-white">{payslip.month}</p>
                  <p className="text-sm text-slate-400">{payslip.date}</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-sm text-slate-400">Net Pay</p>
                    <p className="text-lg font-bold text-cyan-400">{payslip.netPay}</p>
                  </div>
                  <Button variant="ghost" size="sm" className="text-cyan-400 hover:text-cyan-300">
                    <Download className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
