"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Calendar, Search } from "lucide-react"

export default function AttendanceManagementSection() {
  const attendanceRecords = [
    { date: "Jan 16, 2025", present: 142, absent: 14, halfDay: 0, onLeave: 0 },
    { date: "Jan 15, 2025", present: 140, absent: 12, halfDay: 2, onLeave: 2 },
    { date: "Jan 14, 2025", present: 144, absent: 10, halfDay: 1, onLeave: 1 },
    { date: "Jan 13, 2025", present: 138, absent: 15, halfDay: 2, onLeave: 1 },
  ]

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-white">Attendance Management</h2>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-300">Present Today</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-400">142</div>
            <p className="text-xs text-slate-400 mt-1">91% of workforce</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-300">Absent Today</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-400">14</div>
            <p className="text-xs text-slate-400 mt-1">9% of workforce</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-300">Half-day</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-yellow-400">0</div>
            <p className="text-xs text-slate-400 mt-1">Today</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-300">On Leave</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-400">0</div>
            <p className="text-xs text-slate-400 mt-1">Today</p>
          </CardContent>
        </Card>
      </div>

      {/* Filter */}
      <Card className="bg-slate-900 border-slate-700">
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
            <Input type="date" className="pl-10 bg-slate-800 border-slate-700 text-white" />
          </div>
        </CardContent>
      </Card>

      {/* Attendance Records */}
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Daily Records
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="text-left py-3 px-4 text-slate-300 font-semibold">Date</th>
                  <th className="text-center py-3 px-4 text-slate-300 font-semibold">Present</th>
                  <th className="text-center py-3 px-4 text-slate-300 font-semibold">Absent</th>
                  <th className="text-center py-3 px-4 text-slate-300 font-semibold">Half-day</th>
                  <th className="text-center py-3 px-4 text-slate-300 font-semibold">On Leave</th>
                </tr>
              </thead>
              <tbody>
                {attendanceRecords.map((record) => (
                  <tr key={record.date} className="border-b border-slate-800 hover:bg-slate-800 transition">
                    <td className="py-3 px-4 text-slate-300">{record.date}</td>
                    <td className="py-3 px-4 text-center text-green-400 font-semibold">{record.present}</td>
                    <td className="py-3 px-4 text-center text-red-400 font-semibold">{record.absent}</td>
                    <td className="py-3 px-4 text-center text-yellow-400 font-semibold">{record.halfDay}</td>
                    <td className="py-3 px-4 text-center text-blue-400 font-semibold">{record.onLeave}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
