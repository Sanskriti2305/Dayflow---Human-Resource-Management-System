"use client"

import { useState } from "react"
import { useEffect } from "react"
import { supabase } from "@/lib/supabaseClient"
import SignInPage from "@/components/sign-in-page"
import SignUpPage from "@/components/sign-up-page"
import EmployeeDashboard from "@/components/employee-dashboard"
import AdminDashboard from "@/components/admin-dashboard"

type Role = "employee" | "admin" | null
type AuthMode = "signin" | "signup"

export default function Home() {
  const [role, setRole] = useState<Role>(null)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [authMode, setAuthMode] = useState<AuthMode>("signin")

  const handleLogin = (userRole: "employee" | "admin") => {
    setRole(userRole)
    setIsLoggedIn(true)
  }

  const handleLogout = async () => {
    await supabase.auth.signOut()
    setIsLoggedIn(false)
    setRole(null)
    setAuthMode("signin")
  }

  
  useEffect(() => {
    const restoreSession = async () => {
      const { data } = await supabase.auth.getSession()

      if (data.session) {
        setIsLoggedIn(true)
        setRole("admin") // TEMP (we'll fetch real role later)
      }
    }

    restoreSession()
  }, [])


  if (!isLoggedIn) {
    return (
      <>
        {authMode === "signin" ? (
          <SignInPage onLogin={handleLogin} onSwitchToSignup={() => setAuthMode("signup")} />
        ) : (
          <SignUpPage onSignupComplete={handleLogin} onSwitchToSignin={() => setAuthMode("signin")} />
        )}
      </>
    )
  }

  return role === "admin" ? <AdminDashboard onLogout={handleLogout} /> : <EmployeeDashboard onLogout={handleLogout} />
}
