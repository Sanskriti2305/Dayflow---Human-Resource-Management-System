"use client"

import { useEffect, useState } from "react"
import { supabase } from "@/lib/supabaseClient"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function LeaveApprovalSection() {
  const [leaves, setLeaves] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  const statusColors: Record<string, string> = {
    pending: "bg-yellow-900 text-yellow-200",
    approved: "bg-green-900 text-green-200",
    rejected: "bg-red-900 text-red-200",
  }

  useEffect(() => {
    fetchAllLeaves()
  }, [])

  // ✅ ADMIN FETCHES ALL LEAVES (NO FILTERS, NO ROLE LOGIC)
  const fetchAllLeaves = async () => {
    setLoading(true)

    const { data, error } = await supabase
      .from("leave_requests")
      .select(`
        id,
        start_date,
        end_date,
        reason,
        status,
        user_id,
        users:user_id (
          name
        )
      `)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Error fetching leaves:", error)
      alert("Failed to load leave requests")
    } else {
      setLeaves(data || [])
    }

    setLoading(false)
  }

  // ✅ APPROVE / REJECT (NO OVERTHINKING)
  const updateLeaveStatus = async (
    leaveId: number,
    newStatus: "approved" | "rejected"
  ) => {
    const { error } = await supabase
      .from("leave_requests")
      .update({ status: newStatus })
      .eq("id", leaveId)

    if (error) {
      alert(error.message)
      return
    }

    // refresh list
    fetchAllLeaves()
  }

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-white">Leave Approvals</h2>

      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">
            Employee Leave Requests
          </CardTitle>
        </CardHeader>

        <CardContent>
          {loading ? (
            <p className="text-slate-400 text-center py-8">Loading...</p>
          ) : leaves.length === 0 ? (
            <p className="text-slate-400 text-center py-8">
              No leave requests found
            </p>
          ) : (
            <div className="space-y-4">
              {leaves.map((leave) => (
                <div
                  key={leave.id}
                  className="p-4 rounded-lg bg-slate-800 border border-slate-700"
                >
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <p className="text-white font-semibold">
                        {leave.users?.name ??
                          `Employee #${leave.user_id}`}
                      </p>
                      <p className="text-sm text-slate-400">
                        {leave.reason || "—"}
                      </p>
                    </div>

                    <span
                      className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        statusColors[leave.status]
                      }`}
                    >
                      {leave.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                    <div>
                      <p className="text-slate-400">From</p>
                      <p className="text-white">{leave.start_date}</p>
                    </div>
                    <div>
                      <p className="text-slate-400">To</p>
                      <p className="text-white">{leave.end_date}</p>
                    </div>
                  </div>

                  {leave.status === "pending" && (
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() =>
                          updateLeaveStatus(leave.id, "approved")
                        }
                      >
                        Approve
                      </Button>

                      <Button
                        size="sm"
                        variant="outline"
                        className="border-red-600 text-red-400 hover:bg-red-900"
                        onClick={() =>
                          updateLeaveStatus(leave.id, "rejected")
                        }
                      >
                        Reject
                      </Button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
