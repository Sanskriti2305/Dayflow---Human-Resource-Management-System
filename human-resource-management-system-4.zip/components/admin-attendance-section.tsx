"use client"

import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, ChevronLeft, ChevronRight } from "lucide-react"
import { useState } from "react"

export default function AdminAttendanceSection() {
  const [searchQuery, setSearchQuery] = useState("")
  const [viewMode, setViewMode] = useState<"day" | "month">("day")
  const [selectedDate, setSelectedDate] = useState("2025-01-15")

  const attendanceRecords = [
    {
      id: 1,
      name: "John Doe",
      checkIn: "09:00 AM",
      checkOut: "06:00 PM",
      workHours: "8.5h",
      extraHours: "0.5h",
    },
    {
      id: 2,
      name: "Jane Smith",
      checkIn: "09:15 AM",
      checkOut: "05:55 PM",
      workHours: "8.4h",
      extraHours: "0h",
    },
    {
      id: 3,
      name: "Tom Brown",
      checkIn: "09:05 AM",
      checkOut: "06:00 PM",
      workHours: "8.5h",
      extraHours: "0.5h",
    },
    {
      id: 4,
      name: "Alice Johnson",
      checkIn: "09:30 AM",
      checkOut: "06:30 PM",
      workHours: "8.75h",
      extraHours: "0.75h",
    },
    {
      id: 5,
      name: "Mike Davis",
      checkIn: "08:55 AM",
      checkOut: "06:15 PM",
      workHours: "8.8h",
      extraHours: "0.8h",
    },
  ]

  const filteredAttendance = attendanceRecords.filter((emp) =>
    emp.name.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handlePreviousDay = () => {
    const date = new Date(selectedDate)
    date.setDate(date.getDate() - 1)
    setSelectedDate(date.toISOString().split("T")[0])
  }

  const handleNextDay = () => {
    const date = new Date(selectedDate)
    date.setDate(date.getDate() + 1)
    setSelectedDate(date.toISOString().split("T")[0])
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
          <Input
            placeholder="Search employees..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-white border-gray-300 text-gray-900 placeholder:text-gray-500"
          />
        </div>
        <Button
          variant="outline"
          size="icon"
          onClick={handlePreviousDay}
          className="bg-white border-gray-300 text-gray-700 hover:bg-gray-100"
        >
          <ChevronLeft className="w-4 h-4" />
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={handleNextDay}
          className="bg-white border-gray-300 text-gray-700 hover:bg-gray-100"
        >
          <ChevronRight className="w-4 h-4" />
        </Button>
        <Input
          type="date"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
          className="w-48 bg-white border-gray-300 text-gray-900"
        />
        <div className="flex gap-2">
          <Button
            variant={viewMode === "day" ? "default" : "outline"}
            size="sm"
            onClick={() => setViewMode("day")}
            className={
              viewMode === "day"
                ? "bg-blue-600 hover:bg-blue-700 text-white"
                : "bg-white border-gray-300 text-gray-700 hover:bg-gray-100"
            }
          >
            Day
          </Button>
          <Button
            variant={viewMode === "month" ? "default" : "outline"}
            size="sm"
            onClick={() => setViewMode("month")}
            className={
              viewMode === "month"
                ? "bg-blue-600 hover:bg-blue-700 text-white"
                : "bg-white border-gray-300 text-gray-700 hover:bg-gray-100"
            }
          >
            Month
          </Button>
        </div>
      </div>

      <div className="border border-gray-200 rounded-lg overflow-hidden bg-white">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-200 bg-gray-50">
              <th className="text-left py-3 px-4 text-gray-700 font-semibold">Employee Name</th>
              <th className="text-left py-3 px-4 text-gray-700 font-semibold">Check In</th>
              <th className="text-left py-3 px-4 text-gray-700 font-semibold">Check Out</th>
              <th className="text-left py-3 px-4 text-gray-700 font-semibold">Work Hours</th>
              <th className="text-left py-3 px-4 text-gray-700 font-semibold">Extra Hours</th>
            </tr>
          </thead>
          <tbody>
            {filteredAttendance.map((record) => (
              <tr key={record.id} className="border-b border-gray-200 hover:bg-gray-50">
                <td className="py-3 px-4 text-gray-900">{record.name}</td>
                <td className="py-3 px-4 text-gray-700">{record.checkIn}</td>
                <td className="py-3 px-4 text-gray-700">{record.checkOut}</td>
                <td className="py-3 px-4 text-gray-700">{record.workHours}</td>
                <td className="py-3 px-4 text-gray-700">{record.extraHours}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {filteredAttendance.length === 0 && (
        <div className="text-center py-8 text-gray-500">No employees found matching your search.</div>
      )}
    </div>
  )
}
