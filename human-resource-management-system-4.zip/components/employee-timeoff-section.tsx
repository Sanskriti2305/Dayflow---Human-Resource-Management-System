"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Plus, Upload, X } from "lucide-react"

export default function EmployeeTimeOffSection() {
  const [showModal, setShowModal] = useState(false)
  const [formData, setFormData] = useState({
    timeOffType: "Paid Time Off",
    startDate: "",
    endDate: "",
    allocation: "1.00",
    attachment: null as File | null,
  })

  const timeOffRequests = [
    {
      id: 1,
      name: "John Doe",
      startDate: "28/10/2025",
      endDate: "28/10/2025",
      type: "Paid Time Off",
      status: "Approved",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold text-white">Time Off</h2>
        <Button onClick={() => setShowModal(true)} className="bg-purple-600 hover:bg-purple-700 text-white">
          <Plus className="w-4 h-4 mr-2" />
          NEW
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div className="border border-slate-600 rounded-lg p-6 bg-slate-950">
          <p className="text-cyan-400 font-semibold mb-2">Paid Time Off</p>
          <p className="text-white text-lg">24 Days Available</p>
        </div>
        <div className="border border-slate-600 rounded-lg p-6 bg-slate-950">
          <p className="text-cyan-400 font-semibold mb-2">Sick Time Off</p>
          <p className="text-white text-lg">07 Days Available</p>
        </div>
      </div>

      <div className="border border-slate-600 rounded-lg overflow-hidden bg-slate-950">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-600 bg-slate-900">
              <th className="text-left py-3 px-4 text-white font-semibold">Name</th>
              <th className="text-left py-3 px-4 text-white font-semibold">Start Date</th>
              <th className="text-left py-3 px-4 text-white font-semibold">End Date</th>
              <th className="text-left py-3 px-4 text-white font-semibold">Time Off Type</th>
              <th className="text-left py-3 px-4 text-white font-semibold">Status</th>
            </tr>
          </thead>
          <tbody>
            {timeOffRequests.map((request) => (
              <tr key={request.id} className="border-b border-slate-700 hover:bg-slate-900 transition">
                <td className="py-3 px-4 text-slate-300">{request.name}</td>
                <td className="py-3 px-4 text-slate-300">{request.startDate}</td>
                <td className="py-3 px-4 text-slate-300">{request.endDate}</td>
                <td className="py-3 px-4 text-cyan-400">{request.type}</td>
                <td className="py-3 px-4">
                  <span className="px-3 py-1 bg-green-900 text-green-300 text-xs rounded font-semibold">
                    {request.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-slate-900 border border-slate-600 rounded-lg p-8 w-full max-w-md">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-white text-lg font-semibold">Time Off Request</h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              {/* Employee - auto-filled */}
              <div>
                <label className="text-slate-300 text-sm block mb-1">Employee</label>
                <div className="text-cyan-400 font-semibold">John Doe</div>
              </div>

              {/* Time Off Type */}
              <div>
                <label className="text-slate-300 text-sm block mb-1">Time Off Type</label>
                <select
                  value={formData.timeOffType}
                  onChange={(e) => setFormData({ ...formData, timeOffType: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded text-cyan-400 p-2"
                >
                  <option>Paid Time Off</option>
                  <option>Sick Leave</option>
                  <option>Unpaid Leave</option>
                </select>
              </div>

              {/* Validity Period (From → To) */}
              <div>
                <label className="text-slate-300 text-sm block mb-1">Validity Period</label>
                <div className="flex gap-2 items-center">
                  <input
                    type="date"
                    value={formData.startDate}
                    onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                    className="flex-1 bg-slate-800 border border-slate-700 rounded text-slate-300 p-2 text-sm"
                  />
                  <span className="text-slate-400">→</span>
                  <input
                    type="date"
                    value={formData.endDate}
                    onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                    className="flex-1 bg-slate-800 border border-slate-700 rounded text-slate-300 p-2 text-sm"
                  />
                </div>
              </div>

              {/* Allocation */}
              <div>
                <label className="text-slate-300 text-sm block mb-1">Allocation</label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    step="0.5"
                    value={formData.allocation}
                    onChange={(e) => setFormData({ ...formData, allocation: e.target.value })}
                    className="flex-1 bg-slate-800 border border-slate-700 rounded text-white p-2"
                  />
                  <span className="text-slate-400 flex items-center">Days</span>
                </div>
              </div>

              {/* Attachment upload (REQUIRED for Sick Leave) */}
              <div>
                <label className="text-slate-300 text-sm block mb-1">
                  Attachment {formData.timeOffType === "Sick Leave" && <span className="text-red-400">*</span>}
                </label>
                <p className="text-xs text-slate-400 mb-2">
                  {formData.timeOffType === "Sick Leave" ? "Required for sick leave" : "Optional"}
                </p>
                <label className="cursor-pointer">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 bg-cyan-600 rounded flex items-center justify-center hover:bg-cyan-700 transition">
                      <Upload className="w-5 h-5 text-white" />
                    </div>
                    {formData.attachment && <span className="text-slate-300 text-sm">{formData.attachment.name}</span>}
                  </div>
                  <input
                    type="file"
                    className="hidden"
                    onChange={(e) => setFormData({ ...formData, attachment: e.target.files?.[0] || null })}
                  />
                </label>
              </div>

              {/* Buttons: Submit and Discard */}
              <div className="flex gap-3 pt-4">
                <Button className="flex-1 bg-purple-600 hover:bg-purple-700 text-white">Submit</Button>
                <Button
                  onClick={() => setShowModal(false)}
                  variant="outline"
                  className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-800"
                >
                  Discard
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
