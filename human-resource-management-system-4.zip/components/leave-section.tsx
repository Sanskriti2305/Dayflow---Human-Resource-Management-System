"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { FileText, Plus } from "lucide-react"

export default function LeaveSection() {
  const [showForm, setShowForm] = useState(false)

  const leaveRequests = [
    {
      id: 1,
      type: "Paid Leave",
      from: "Jan 20, 2025",
      to: "Jan 22, 2025",
      status: "Pending",
      remarks: "Personal reasons",
    },
    {
      id: 2,
      type: "Sick Leave",
      from: "Jan 10, 2025",
      to: "Jan 10, 2025",
      status: "Approved",
      remarks: "Medical visit",
    },
    { id: 3, type: "Paid Leave", from: "Jan 05, 2025", to: "Jan 05, 2025", status: "Rejected", remarks: "Event" },
  ]

  const statusColors = {
    Pending: "bg-yellow-900 text-yellow-200",
    Approved: "bg-green-900 text-green-200",
    Rejected: "bg-red-900 text-red-200",
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-white">Leave Requests</h2>
        <Button onClick={() => setShowForm(!showForm)} className="bg-cyan-600 hover:bg-cyan-700">
          <Plus className="w-4 h-4 mr-2" />
          New Request
        </Button>
      </div>

      {/* Leave Balance */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-300">Paid Leave</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-cyan-400">8</div>
            <p className="text-xs text-slate-400 mt-1">Days remaining</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-300">Sick Leave</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-cyan-400">5</div>
            <p className="text-xs text-slate-400 mt-1">Days remaining</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-300">Unpaid Leave</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-cyan-400">Unlimited</div>
            <p className="text-xs text-slate-400 mt-1">Subject to approval</p>
          </CardContent>
        </Card>
      </div>

      {/* New Request Form */}
      {showForm && (
        <Card className="bg-slate-900 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Apply for Leave</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-slate-300">Leave Type</label>
                <select className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-lg text-white p-2">
                  <option>Paid Leave</option>
                  <option>Sick Leave</option>
                  <option>Unpaid Leave</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium text-slate-300">From Date</label>
                <Input type="date" className="bg-slate-800 border-slate-700 text-white mt-1" />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-300">To Date</label>
                <Input type="date" className="bg-slate-800 border-slate-700 text-white mt-1" />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-300">Remarks</label>
                <Input placeholder="Reason for leave" className="bg-slate-800 border-slate-700 text-white mt-1" />
              </div>
            </div>
            <div className="flex gap-2">
              <Button className="bg-cyan-600 hover:bg-cyan-700">Submit Request</Button>
              <Button onClick={() => setShowForm(false)} variant="outline" className="border-slate-600">
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Leave Requests Table */}
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Your Requests
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="text-left py-3 px-4 text-slate-300 font-semibold">Type</th>
                  <th className="text-left py-3 px-4 text-slate-300 font-semibold">From</th>
                  <th className="text-left py-3 px-4 text-slate-300 font-semibold">To</th>
                  <th className="text-left py-3 px-4 text-slate-300 font-semibold">Status</th>
                  <th className="text-left py-3 px-4 text-slate-300 font-semibold">Remarks</th>
                </tr>
              </thead>
              <tbody>
                {leaveRequests.map((request) => (
                  <tr key={request.id} className="border-b border-slate-800 hover:bg-slate-800 transition">
                    <td className="py-3 px-4 text-slate-300">{request.type}</td>
                    <td className="py-3 px-4 text-slate-300">{request.from}</td>
                    <td className="py-3 px-4 text-slate-300">{request.to}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold ${statusColors[request.status as keyof typeof statusColors]}`}
                      >
                        {request.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-400 text-xs">{request.remarks}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
