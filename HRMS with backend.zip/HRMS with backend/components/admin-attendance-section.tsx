"use client"

import { useEffect, useState } from "react"
import { supabase } from "@/lib/supabaseClient"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface AttendanceRecord {
  id: string
  date: string
  check_in: string | null
  check_out: string | null
  work_hours: number | null
  extra_hours: number | null
}

export default function EmployeeAttendanceSection() {
  const currentDate = new Date()

  const [selectedMonth, setSelectedMonth] = useState(currentDate.getMonth())
  const [selectedYear, setSelectedYear] = useState(currentDate.getFullYear())
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([])

  const months = [
    "January","February","March","April","May","June",
    "July","August","September","October","November","December",
  ]

  // 🔄 FETCH REAL ATTENDANCE
  useEffect(() => {
    fetchAttendance()
  }, [selectedMonth, selectedYear])

  const fetchAttendance = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) return

    const startDate = new Date(selectedYear, selectedMonth, 1).toISOString()
    const endDate = new Date(selectedYear, selectedMonth + 1, 0).toISOString()

    const { data, error } = await supabase
      .from("attendance")
      .select("*")
      .eq("user_id", user.id)
      .gte("date", startDate)
      .lte("date", endDate)
      .order("date", { ascending: true })

    if (error) {
      console.error(error)
      alert("Failed to load attendance")
      return
    }

    setAttendanceRecords(data || [])
  }

  const presentDays = attendanceRecords.length
  const leavesDays = 0
  const totalWorkingDays = 22

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="flex items-center gap-4 flex-wrap">
        <Button variant="outline" size="icon" className="bg-gray-100 text-gray-700">
          <ChevronLeft className="w-4 h-4" />
        </Button>
        <Button variant="outline" size="icon" className="bg-gray-100 text-gray-700">
          <ChevronRight className="w-4 h-4" />
        </Button>

        <Select
          value={months[selectedMonth]}
          onValueChange={(val) => setSelectedMonth(months.indexOf(val))}
        >
          <SelectTrigger className="bg-gray-100 text-gray-700">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {months.map((month) => (
              <SelectItem key={month} value={month}>
                {month}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <div className="flex gap-4 ml-auto">
          <div className="px-4 py-2 bg-green-100 text-green-700 rounded-lg border">
            <span className="font-semibold">{presentDays}</span> Days Present
          </div>
          <div className="px-4 py-2 bg-blue-100 text-blue-700 rounded-lg border">
            <span className="font-semibold">{leavesDays}</span> Leaves
          </div>
          <div className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg border">
            <span className="font-semibold">{totalWorkingDays}</span> Total Working Days
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="border border-gray-200 rounded-lg overflow-hidden bg-white">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b bg-gray-50">
              <th className="text-left py-3 px-4">Date</th>
              <th className="text-left py-3 px-4">Check In</th>
              <th className="text-left py-3 px-4">Check Out</th>
              <th className="text-left py-3 px-4">Work Hours</th>
              <th className="text-left py-3 px-4">Extra Hours</th>
            </tr>
          </thead>
          <tbody>
            {attendanceRecords.map((record) => (
              <tr key={record.id} className="border-b hover:bg-gray-50">
                <td className="py-3 px-4">
                  {new Date(record.date).toLocaleDateString()}
                </td>
                <td className="py-3 px-4">
                  {record.check_in
                    ? new Date(record.check_in).toLocaleTimeString()
                    : "-"}
                </td>
                <td className="py-3 px-4">
                  {record.check_out
                    ? new Date(record.check_out).toLocaleTimeString()
                    : "-"}
                </td>
                <td className="py-3 px-4">
                  {record.work_hours ?? "-"}
                </td>
                <td className="py-3 px-4">
                  {record.extra_hours ?? "-"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {attendanceRecords.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          No attendance records for this period.
        </div>
      )}
    </div>
  )
}
