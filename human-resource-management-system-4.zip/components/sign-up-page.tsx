"use client"

import type React from "react"
import { useState, useRef } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Upload, Eye, EyeOff, Copy, CheckCircle2 } from "lucide-react"

interface SignUpPageProps {
  onSignupComplete: (role: "employee" | "admin") => void
  onSwitchToSignin: () => void
}

export default function SignUpPage({ onSignupComplete, onSwitchToSignin }: SignUpPageProps) {
  const [companyName, setCompanyName] = useState("")
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [logo, setLogo] = useState<string | null>(null)
  const [signupSuccess, setSignupSuccess] = useState(false)
  const [generatedLoginId, setGeneratedLoginId] = useState("")
  const [generatedPassword, setGeneratedPassword] = useState("")
  const [copiedLoginId, setCopiedLoginId] = useState(false)
  const [copiedPassword, setCopiedPassword] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const generateLoginId = (company: string, fullName: string) => {
    if (!company || !fullName) return ""

    const companyCode = company
      .split(" ")
      .map((word) => word[0])
      .join("")
      .toUpperCase()
      .slice(0, 2)

    const nameParts = fullName.trim().split(" ")
    const firstName = nameParts[0] || ""
    const lastName = nameParts[nameParts.length - 1] || ""

    const firstInitials = firstName.slice(0, 2).toUpperCase()
    const lastInitials = lastName.slice(0, 2).toUpperCase()

    const year = new Date().getFullYear()
    const serial = "0001"

    return `${companyCode}${firstInitials}${lastInitials}${year}${serial}`
  }

  const generateSecurePassword = () => {
    const length = 12
    const uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    const lowercase = "abcdefghijklmnopqrstuvwxyz"
    const numbers = "0123456789"
    const symbols = "!@#$%^&*"
    const allChars = uppercase + lowercase + numbers + symbols

    let password = ""
    password += uppercase[Math.floor(Math.random() * uppercase.length)]
    password += lowercase[Math.floor(Math.random() * lowercase.length)]
    password += numbers[Math.floor(Math.random() * numbers.length)]
    password += symbols[Math.floor(Math.random() * symbols.length)]

    for (let i = password.length; i < length; i++) {
      password += allChars[Math.floor(Math.random() * allChars.length)]
    }

    return password
      .split("")
      .sort(() => Math.random() - 0.5)
      .join("")
  }

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setLogo(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (companyName && name && email && phone && password && confirmPassword) {
      if (password !== confirmPassword) {
        alert("Passwords do not match!")
        return
      }

      const loginId = generateLoginId(companyName, name)
      const autoPassword = generateSecurePassword()

      setGeneratedLoginId(loginId)
      setGeneratedPassword(autoPassword)
      setSignupSuccess(true)
    }
  }

  const copyToClipboard = (text: string, type: "loginId" | "password") => {
    navigator.clipboard.writeText(text)
    if (type === "loginId") {
      setCopiedLoginId(true)
      setTimeout(() => setCopiedLoginId(false), 2000)
    } else {
      setCopiedPassword(true)
      setTimeout(() => setCopiedPassword(false), 2000)
    }
  }

  if (signupSuccess) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
        <div className="w-full max-w-md border-2 border-slate-600 rounded-lg p-8 bg-slate-950">
          <div className="text-center mb-6">
            <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-light text-slate-200 mb-2">Sign Up Successful!</h2>
            <p className="text-slate-400 text-sm">Employee credentials generated successfully</p>
          </div>

          <div className="space-y-4">
            <div className="bg-slate-800 border border-slate-700 rounded-lg p-4">
              <label className="text-slate-400 text-xs font-light block mb-2">Login ID</label>
              <div className="flex items-center justify-between">
                <code className="text-slate-200 font-mono text-sm">{generatedLoginId}</code>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(generatedLoginId, "loginId")}
                  className="text-blue-400 hover:text-blue-300"
                >
                  {copiedLoginId ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
            </div>

            <div className="bg-slate-800 border border-slate-700 rounded-lg p-4">
              <label className="text-slate-400 text-xs font-light block mb-2">Generated Password</label>
              <div className="flex items-center justify-between">
                <code className="text-slate-200 font-mono text-sm">{generatedPassword}</code>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(generatedPassword, "password")}
                  className="text-blue-400 hover:text-blue-300"
                >
                  {copiedPassword ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
            </div>

            <div className="bg-amber-900/20 border border-amber-700/50 rounded-lg p-4 mt-4">
              <p className="text-amber-200 text-xs font-light">
                ⚠️ Save these credentials securely. Share them with the employee through a secure channel.
              </p>
            </div>
          </div>

          <Button
            onClick={() => onSignupComplete("admin")}
            className="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 rounded mt-6"
          >
            Continue to Dashboard
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl border-2 border-slate-600 rounded-lg p-8 bg-slate-950">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-6">
            <div className="relative w-24 h-24 rounded-full overflow-hidden border-2 border-slate-600">
              <Image src="/company-logo.jpg" alt="Company Logo" fill className="object-cover" priority />
            </div>
          </div>
          <div className="text-xl font-light text-slate-400">Sign Up</div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <label className="text-slate-300 font-light text-sm">Company Name</label>
            <div className="flex gap-2">
              <Input
                type="text"
                placeholder="Enter company name"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                required
                className="flex-1 bg-slate-900 border-slate-600 text-slate-200 placeholder:text-slate-600"
              />
              <Button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                variant="outline"
                size="icon"
                className="border-slate-600 hover:bg-slate-800"
              >
                <Upload className="w-4 h-4 text-blue-400" />
              </Button>
              <input ref={fileInputRef} type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
            </div>
            {logo && (
              <div className="mt-2">
                <img
                  src={logo || "/placeholder.svg"}
                  alt="Company Logo"
                  className="w-20 h-20 rounded object-cover border border-slate-600"
                />
              </div>
            )}
          </div>

          <div className="space-y-2">
            <label className="text-slate-300 font-light text-sm">Name</label>
            <Input
              type="text"
              placeholder="Enter your full name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              className="bg-slate-900 border-slate-600 text-slate-200 placeholder:text-slate-600"
            />
          </div>

          <div className="space-y-2">
            <label className="text-slate-300 font-light text-sm">Email</label>
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="bg-slate-900 border-slate-600 text-slate-200 placeholder:text-slate-600"
            />
          </div>

          <div className="space-y-2">
            <label className="text-slate-300 font-light text-sm">Phone</label>
            <Input
              type="tel"
              placeholder="Enter your phone number"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required
              className="bg-slate-900 border-slate-600 text-slate-200 placeholder:text-slate-600"
            />
          </div>

          <div className="space-y-2">
            <label className="text-slate-300 font-light text-sm">Password</label>
            <div className="relative">
              <Input
                type={showPassword ? "text" : "password"}
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="bg-slate-900 border-slate-600 text-slate-200 placeholder:text-slate-600 pr-10"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-300"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-slate-300 font-light text-sm">Confirm Password</label>
            <div className="relative">
              <Input
                type={showConfirmPassword ? "text" : "password"}
                placeholder="Confirm your password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                className="bg-slate-900 border-slate-600 text-slate-200 placeholder:text-slate-600 pr-10"
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-300"
              >
                {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <Button
            type="submit"
            className="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 rounded mt-6"
          >
            Sign Up
          </Button>
        </form>

        <div className="text-center mt-6">
          <button
            onClick={onSwitchToSignin}
            className="text-slate-400 text-sm font-light hover:text-slate-300 transition"
          >
            Already have an account? Sign In
          </button>
        </div>
      </div>
    </div>
  )
}
