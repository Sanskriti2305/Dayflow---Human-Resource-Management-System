"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Plus, Trash2 } from "lucide-react"
import { useState } from "react"

interface SalaryComponent {
  name: string
  type: "fixed" | "percentage"
  amount: number
  percentage?: number
}

export default function SalaryInfoSection() {
  const [monthlyWage, setMonthlyWage] = useState(50000)
  const [components, setComponents] = useState<SalaryComponent[]>([
    { name: "Basic Salary", type: "percentage", amount: 25000, percentage: 50 },
    { name: "House Rent Allowance", type: "percentage", amount: 12500, percentage: 25 },
    { name: "Standard Allowance", type: "fixed", amount: 5000 },
    { name: "Performance Bonus", type: "percentage", amount: 4167, percentage: 8.33 },
  ])

  const [pfContribution] = useState({
    employee: 1000,
    employer: 1000,
    rate: 12,
  })

  const [taxDeductions] = useState({
    professional: 200,
    other: 100,
  })

  const totalComponents = components.reduce((sum, comp) => sum + comp.amount, 0)

  const handleAddComponent = () => {
    setComponents([...components, { name: "New Component", type: "fixed", amount: 0 }])
  }

  const handleDeleteComponent = (index: number) => {
    setComponents(components.filter((_, i) => i !== index))
  }

  const handleComponentChange = (index: number, field: string, value: any) => {
    const newComponents = [...components]
    newComponents[index] = { ...newComponents[index], [field]: value }
    setComponents(newComponents)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-gray-900">Salary Information</h2>
        <p className="text-gray-600 text-sm">Salary Info tab is only visible to Admin</p>
      </div>

      {/* Wage Information */}
      <Card className="bg-white border border-gray-200">
        <CardHeader>
          <CardTitle className="text-gray-900">Wage Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-6">
            <div>
              <label className="text-gray-600 text-sm">Month Wage</label>
              <div className="flex items-center gap-2 mt-2">
                <Input
                  type="number"
                  value={monthlyWage}
                  onChange={(e) => setMonthlyWage(Number(e.target.value))}
                  className="bg-white border-gray-300 text-gray-900"
                />
                <span className="text-gray-600">/ Month</span>
              </div>
            </div>
            <div>
              <label className="text-gray-600 text-sm">Yearly wage</label>
              <div className="flex items-center gap-2 mt-2">
                <Input
                  type="number"
                  value={monthlyWage * 12}
                  disabled
                  className="bg-gray-50 border-gray-300 text-gray-600"
                />
                <span className="text-gray-600">/ Yearly</span>
              </div>
            </div>
            <div>
              <label className="text-gray-600 text-sm">No of working days in a week</label>
              <Input type="number" defaultValue={5} className="bg-white border-gray-300 text-gray-900 mt-2" />
            </div>
            <div>
              <label className="text-gray-600 text-sm">Break Time</label>
              <div className="flex items-center gap-2 mt-2">
                <Input type="number" defaultValue={1} className="bg-white border-gray-300 text-gray-900" />
                <span className="text-gray-600">/ hrs</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Salary Components */}
      <Card className="bg-white border border-gray-200">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-gray-900">Salary Components</CardTitle>
            <Button onClick={handleAddComponent} className="bg-blue-600 hover:bg-blue-700 gap-2" size="sm">
              <Plus className="w-4 h-4" />
              Add Component
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {components.map((component, index) => (
            <div key={index} className="p-4 bg-gray-50 border border-gray-200 rounded-lg space-y-3">
              <div className="flex justify-between items-start gap-4">
                <Input
                  value={component.name}
                  onChange={(e) => handleComponentChange(index, "name", e.target.value)}
                  placeholder="Component name"
                  className="bg-white border-gray-300 text-gray-900"
                />
                <Button
                  onClick={() => handleDeleteComponent(index)}
                  variant="ghost"
                  size="sm"
                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="text-gray-600 text-xs">Type</label>
                  <select
                    value={component.type}
                    onChange={(e) => handleComponentChange(index, "type", e.target.value as "fixed" | "percentage")}
                    className="w-full bg-white border border-gray-300 text-gray-900 rounded px-3 py-2 mt-1 text-sm"
                  >
                    <option value="fixed">Fixed Amount</option>
                    <option value="percentage">Percentage</option>
                  </select>
                </div>

                <div>
                  <label className="text-gray-600 text-xs">Amount</label>
                  <Input
                    type="number"
                    value={component.amount}
                    onChange={(e) => handleComponentChange(index, "amount", Number(e.target.value))}
                    placeholder="0"
                    className="bg-white border-gray-300 text-gray-900 mt-1"
                  />
                </div>

                <div>
                  <label className="text-gray-600 text-xs">{component.type === "percentage" ? "%" : "Value"}</label>
                  {component.type === "percentage" ? (
                    <Input
                      type="number"
                      value={component.percentage}
                      onChange={(e) => handleComponentChange(index, "percentage", Number(e.target.value))}
                      placeholder="0"
                      className="bg-white border-gray-300 text-gray-900 mt-1"
                    />
                  ) : (
                    <div className="mt-1 py-2 px-3 bg-gray-50 border border-gray-300 rounded text-gray-900 text-sm">
                      ₹ {component.amount}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Summary */}
      <div className="grid grid-cols-2 gap-6">
        <Card className="bg-white border border-gray-200">
          <CardContent className="p-6 space-y-3">
            <div className="flex justify-between text-gray-700">
              <span>Total Salary Components:</span>
              <span className="font-semibold">₹ {totalComponents.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-gray-700">
              <span>PF Contribution (Employee):</span>
              <span className="font-semibold">₹ {pfContribution.employee}</span>
            </div>
            <div className="flex justify-between text-gray-700">
              <span>PF Contribution (Employer):</span>
              <span className="font-semibold">₹ {pfContribution.employer}</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border border-gray-200">
          <CardContent className="p-6 space-y-3">
            <div className="flex justify-between text-gray-700">
              <span>Professional Tax:</span>
              <span className="font-semibold">₹ {taxDeductions.professional}</span>
            </div>
            <div className="flex justify-between text-gray-700">
              <span>Other Deductions:</span>
              <span className="font-semibold">₹ {taxDeductions.other}</span>
            </div>
            <div className="border-t border-gray-200 pt-3 flex justify-between text-gray-900 font-bold">
              <span>Net Salary:</span>
              <span className="text-blue-600">
                ₹{" "}
                {(
                  totalComponents -
                  pfContribution.employee -
                  taxDeductions.professional -
                  taxDeductions.other
                ).toLocaleString()}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
