"use client"

import { useState } from "react"
import TopNavbar from "./top-navbar"
import EmployeeGridSection from "./employee-grid-section"
import EmployeeProfileSection from "./employee-profile-section"
import EmployeeAttendanceSection from "./employee-attendance-section"
import EmployeeTimeOffSection from "./employee-timeoff-section"

interface EmployeeDashboardProps {
  onLogout: () => void
}

export default function EmployeeDashboard({ onLogout }: EmployeeDashboardProps) {
  const [activeNav, setActiveNav] = useState<string>("employees")

  return (
    <div className="flex flex-col min-h-screen bg-slate-950">
      <TopNavbar role="employee" activeNav={activeNav} onNavChange={setActiveNav} onLogout={onLogout} />

      <main className="flex-1 p-8">
        {activeNav === "employees" && <EmployeeGridSection role="employee" />}
        {activeNav === "attendance" && <EmployeeAttendanceSection />}
        {activeNav === "time off" && <EmployeeTimeOffSection />}
        {activeNav === "my profile" && <EmployeeProfileSection />}
      </main>
    </div>
  )
}
