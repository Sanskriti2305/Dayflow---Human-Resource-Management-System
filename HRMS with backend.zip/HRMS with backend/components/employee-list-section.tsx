"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Users, Search, Edit2 } from "lucide-react"

export default function EmployeeListSection() {
  const employees = [
    { id: 1, name: "John Doe", email: "john.doe@company.com", dept: "Engineering", status: "Active" },
    { id: 2, name: "Jane Smith", email: "jane.smith@company.com", dept: "HR", status: "Active" },
    { id: 3, name: "Mike Johnson", email: "mike.johnson@company.com", dept: "Sales", status: "Active" },
    { id: 4, name: "Sarah Williams", email: "sarah.williams@company.com", dept: "Engineering", status: "On Leave" },
    { id: 5, name: "Tom Brown", email: "tom.brown@company.com", dept: "Finance", status: "Active" },
  ]

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-white">Employee List</h2>

      {/* Search Bar */}
      <Card className="bg-slate-900 border-slate-700">
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
            <Input
              placeholder="Search by name or email..."
              className="pl-10 bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
            />
          </div>
        </CardContent>
      </Card>

      {/* Employees Table */}
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Users className="w-5 h-5" />
            All Employees ({employees.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="text-left py-3 px-4 text-slate-300 font-semibold">Name</th>
                  <th className="text-left py-3 px-4 text-slate-300 font-semibold">Email</th>
                  <th className="text-left py-3 px-4 text-slate-300 font-semibold">Department</th>
                  <th className="text-left py-3 px-4 text-slate-300 font-semibold">Status</th>
                  <th className="text-left py-3 px-4 text-slate-300 font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {employees.map((employee) => (
                  <tr key={employee.id} className="border-b border-slate-800 hover:bg-slate-800 transition">
                    <td className="py-3 px-4 font-medium text-white">{employee.name}</td>
                    <td className="py-3 px-4 text-slate-400">{employee.email}</td>
                    <td className="py-3 px-4 text-slate-300">{employee.dept}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          employee.status === "Active" ? "bg-green-900 text-green-200" : "bg-yellow-900 text-yellow-200"
                        }`}
                      >
                        {employee.status}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <Button variant="ghost" size="sm" className="text-cyan-400 hover:text-cyan-300">
                        <Edit2 className="w-4 h-4" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
