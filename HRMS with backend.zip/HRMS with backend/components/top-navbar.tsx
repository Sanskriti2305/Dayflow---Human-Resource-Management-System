"use client"

import { LogOut, User } from "lucide-react"
import Image from "next/image"
import { useState, useRef, useEffect } from "react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

interface TopNavbarProps {
  role: "admin" | "employee"
  activeNav: string
  onNavChange: (nav: string) => void
  onLogout: () => void
}

export default function TopNavbar({ role, activeNav, onNavChange, onLogout }: TopNavbarProps) {
  const navItems = ["Employees", "Attendance", "Time Off"]
  const [isCheckedIn, setIsCheckedIn] = useState(true)
  const [showCheckInDropdown, setShowCheckInDropdown] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowCheckInDropdown(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const handleCheckIn = () => {
    setIsCheckedIn(true)
    setShowCheckInDropdown(false)
  }

  const handleCheckOut = () => {
    setIsCheckedIn(false)
    setShowCheckInDropdown(false)
  }

  return (
    <div className="bg-background border-b border-border/50 px-8 py-5">
      <div className="flex items-center justify-between max-w-7xl mx-auto">
        {/* Logo and Nav Items */}
        <div className="flex items-center gap-12">
          <div className="flex items-center gap-3 group cursor-pointer">
            <div className="relative w-10 h-10 overflow-hidden rounded-xl shadow-[0_0_20px_rgba(34,197,94,0.2)] transition-transform group-hover:scale-105">
              <Image src="/company-logo.jpg" alt="Dayflow Logo" fill className="object-cover" />
            </div>
            <span className="text-foreground font-bold tracking-tight text-xl">Dayflow</span>
          </div>

          {/* Navigation Items */}
          <nav className="flex items-center gap-8">
            {navItems.map((item) => (
              <button
                key={item}
                onClick={() => onNavChange(item.toLowerCase())}
                className={`text-[13px] uppercase tracking-widest font-semibold transition-all duration-300 relative py-1 ${
                  activeNav === item.toLowerCase() ? "text-primary" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {item}
                {activeNav === item.toLowerCase() && (
                  <div className="absolute -bottom-1 left-0 w-full h-0.5 bg-primary rounded-full shadow-[0_0_10px_rgba(var(--primary),0.5)]" />
                )}
              </button>
            ))}
          </nav>
        </div>

        {/* Right Side - Status Dot and Avatar */}
        <div className="flex items-center gap-4">
          {/* Status Dot with Check-in/Check-out Popover */}
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setShowCheckInDropdown(!showCheckInDropdown)}
              className={`w-10 h-10 rounded-full cursor-pointer hover:ring-2 hover:ring-offset-2 transition-all ${
                isCheckedIn ? "bg-green-500 hover:ring-green-500" : "bg-red-500 hover:ring-red-500"
              }`}
              aria-label={isCheckedIn ? "Checked In" : "Not Checked In"}
            />

            {showCheckInDropdown && (
              <div className="absolute right-0 top-full mt-2 w-40 bg-background border border-border rounded-lg shadow-lg overflow-hidden z-50">
                <button
                  onClick={handleCheckIn}
                  disabled={isCheckedIn}
                  className={`w-full px-4 py-2.5 text-left text-sm transition-colors flex items-center gap-2 ${
                    isCheckedIn ? "opacity-50 cursor-not-allowed" : "hover:bg-muted cursor-pointer"
                  }`}
                >
                  <div className="w-2 h-2 rounded-full bg-green-500" />
                  Check In
                </button>
                <button
                  onClick={handleCheckOut}
                  disabled={!isCheckedIn}
                  className={`w-full px-4 py-2.5 text-left text-sm transition-colors flex items-center gap-2 ${
                    !isCheckedIn ? "opacity-50 cursor-not-allowed" : "hover:bg-muted cursor-pointer"
                  }`}
                >
                  <div className="w-2 h-2 rounded-full bg-red-500" />
                  Check Out
                </button>
              </div>
            )}
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="relative w-10 h-10 rounded-2xl bg-muted border border-border flex items-center justify-center text-foreground font-semibold overflow-hidden hover:border-primary/50 transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
                JD
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={() => onNavChange("my profile")} className="cursor-pointer">
                <User className="mr-2 h-4 w-4" />
                My Profile
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={onLogout} variant="destructive" className="cursor-pointer">
                <LogOut className="mr-2 h-4 w-4" />
                Log Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  )
}
