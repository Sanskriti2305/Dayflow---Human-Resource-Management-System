"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Edit, Plus, Save, X } from "lucide-react"

type UserRole = "admin" | "employee"

export default function AdminProfileSection() {
  const userRole: UserRole = "employee"

  const [isEditingPrivateInfo, setIsEditingPrivateInfo] = useState(false)
  const [privateInfo, setPrivateInfo] = useState({
    dob: "March 15, 1985",
    address: "1234 Oak Street, Apt 567, San Francisco, CA 94102",
    nationality: "American",
    personalEmail: "john.personal@email.com",
    gender: "Male",
    maritalStatus: "Married",
    dateOfJoining: "January 15, 2018",
    bankAccount: "****1234",
    bankName: "Chase Bank",
    ifsc: "CHAS0000001",
    pan: "ABCDE1234F",
    uan: "123456789012",
    empCode: "EMP001",
  })

  const isFieldDisabled = userRole === "employee" || (userRole === "admin" && !isEditingPrivateInfo)

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Profile Header Section */}
      <Card className="border-border/40 bg-card/50 backdrop-blur-sm">
        <CardContent className="p-8">
          <div className="flex flex-col md:flex-row gap-8 items-start">
            {/* Large Avatar with Edit Icon */}
            <div className="relative flex-shrink-0">
              <Avatar className="w-32 h-32 border-4 border-primary/20">
                <AvatarImage src="/placeholder.svg?height=128&width=128" alt="Admin Avatar" />
                <AvatarFallback className="text-3xl font-bold bg-gradient-to-br from-primary to-primary/60 text-primary-foreground">
                  JD
                </AvatarFallback>
              </Avatar>
              <Button
                size="icon"
                variant="secondary"
                className="absolute bottom-0 right-0 rounded-full w-10 h-10 shadow-lg border-2 border-background"
              >
                <Edit className="w-4 h-4" />
              </Button>
            </div>

            {/* Admin Info - Two Column Layout */}
            <div className="flex-1 space-y-6">
              {/* Admin Name - Prominently displayed and underlined */}
              <div>
                <h1 className="text-3xl font-bold text-foreground border-b-2 border-primary pb-2 inline-block">
                  John Doe
                </h1>
              </div>

              {/* Two-column details layout */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-4">
                {/* Left Column */}
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Login ID</p>
                    <p className="text-base font-semibold text-foreground">admin.john.doe</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Email</p>
                    <p className="text-base font-semibold text-foreground">john.doe@company.com</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Mobile</p>
                    <p className="text-base font-semibold text-foreground">+1 (555) 123-4567</p>
                  </div>
                </div>

                {/* Right Column */}
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Company</p>
                    <p className="text-base font-semibold text-foreground">Tech Solutions Inc.</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Department</p>
                    <p className="text-base font-semibold text-foreground">Human Resources</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Manager</p>
                    <p className="text-base font-semibold text-foreground">Sarah Williams</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Location</p>
                    <p className="text-base font-semibold text-foreground">San Francisco, CA</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Profile Tabs */}
      <Tabs defaultValue="resume" className="w-full">
        <TabsList className="w-full justify-start bg-card/50 border border-border/40 p-1">
          <TabsTrigger value="resume" className="flex-1 md:flex-none">
            Resume
          </TabsTrigger>
          <TabsTrigger value="private" className="flex-1 md:flex-none">
            Private Info
          </TabsTrigger>
          <TabsTrigger value="salary" className="flex-1 md:flex-none">
            Salary Info
          </TabsTrigger>
        </TabsList>

        {/* Resume Tab Content */}
        <TabsContent value="resume" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Wider */}
            <div className="lg:col-span-2 space-y-6">
              {/* About Section */}
              <Card className="border-border/40 bg-card/50 backdrop-blur-sm">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-foreground mb-4">About</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Experienced HR professional with over 10 years in talent management, employee relations, and
                    organizational development. Passionate about creating inclusive workplace cultures and implementing
                    data-driven HR strategies that align with business objectives. Proven track record in leading
                    successful recruitment campaigns and employee engagement initiatives.
                  </p>
                </CardContent>
              </Card>

              {/* What I love about my job */}
              <Card className="border-border/40 bg-card/50 backdrop-blur-sm">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-foreground mb-4">What I love about my job</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    I thrive on building meaningful connections with employees and helping them reach their full
                    potential. Every day brings new challenges and opportunities to make a positive impact on people's
                    lives. Whether it's facilitating professional development, resolving conflicts, or celebrating team
                    successes, I find fulfillment in fostering a supportive and dynamic work environment.
                  </p>
                </CardContent>
              </Card>

              {/* My interests and hobbies */}
              <Card className="border-border/40 bg-card/50 backdrop-blur-sm">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-foreground mb-4">My interests and hobbies</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Outside of work, I enjoy hiking and exploring nature trails, which helps me maintain work-life
                    balance and stay energized. I'm an avid reader of leadership and psychology books, always looking to
                    expand my knowledge. I also volunteer at local community centers, teaching resume writing workshops
                    and career guidance sessions to job seekers.
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Right Column - Narrower */}
            <div className="space-y-6">
              {/* Skills Card */}
              <Card className="border-border/40 bg-card/50 backdrop-blur-sm">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-bold text-foreground">Skills</h3>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-primary hover:text-primary/80">
                      <Plus className="w-5 h-5" />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20">
                      Talent Management
                    </Badge>
                    <Badge variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20">
                      Employee Relations
                    </Badge>
                    <Badge variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20">
                      Recruitment
                    </Badge>
                    <Badge variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20">
                      Performance Management
                    </Badge>
                    <Badge variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20">
                      HR Analytics
                    </Badge>
                    <Badge variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20">
                      Conflict Resolution
                    </Badge>
                    <Badge variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20">
                      Leadership
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              {/* Certification Card */}
              <Card className="border-border/40 bg-card/50 backdrop-blur-sm">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-bold text-foreground">Certifications</h3>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-primary hover:text-primary/80">
                      <Plus className="w-5 h-5" />
                    </Button>
                  </div>
                  <div className="space-y-4">
                    <div className="border-l-2 border-primary pl-4 py-1">
                      <p className="font-semibold text-foreground">SHRM-CP Certified Professional</p>
                      <p className="text-sm text-muted-foreground">Society for Human Resource Management</p>
                      <p className="text-xs text-muted-foreground mt-1">2021</p>
                    </div>
                    <div className="border-l-2 border-primary/60 pl-4 py-1">
                      <p className="font-semibold text-foreground">PHR - Professional in Human Resources</p>
                      <p className="text-sm text-muted-foreground">HR Certification Institute</p>
                      <p className="text-xs text-muted-foreground mt-1">2019</p>
                    </div>
                    <div className="border-l-2 border-primary/40 pl-4 py-1">
                      <p className="font-semibold text-foreground">Certified Talent Acquisition Specialist</p>
                      <p className="text-sm text-muted-foreground">LinkedIn Learning</p>
                      <p className="text-xs text-muted-foreground mt-1">2020</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Private Info Tab Content */}
        <TabsContent value="private" className="mt-6">
          <Card className="border-border/40 bg-card/50 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-foreground">Personal Information</h3>
                {userRole === "admin" && (
                  <Button
                    onClick={() => setIsEditingPrivateInfo(!isEditingPrivateInfo)}
                    variant={isEditingPrivateInfo ? "outline" : "default"}
                    size="sm"
                  >
                    {isEditingPrivateInfo ? (
                      <>
                        <X className="w-4 h-4 mr-2" />
                        Cancel
                      </>
                    ) : (
                      <>
                        <Edit className="w-4 h-4 mr-2" />
                        Edit
                      </>
                    )}
                  </Button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Date of Birth</p>
                  <Input
                    value={privateInfo.dob}
                    onChange={(e) => setPrivateInfo({ ...privateInfo, dob: e.target.value })}
                    disabled={isFieldDisabled}
                    className="max-w-md disabled:opacity-70"
                  />
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-1">Gender</p>
                  <Input
                    value={privateInfo.gender}
                    onChange={(e) => setPrivateInfo({ ...privateInfo, gender: e.target.value })}
                    disabled={isFieldDisabled}
                    className="max-w-md disabled:opacity-70"
                  />
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-1">Nationality</p>
                  <Input
                    value={privateInfo.nationality}
                    onChange={(e) => setPrivateInfo({ ...privateInfo, nationality: e.target.value })}
                    disabled={isFieldDisabled}
                    className="max-w-md disabled:opacity-70"
                  />
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-1">Marital Status</p>
                  <Input
                    value={privateInfo.maritalStatus}
                    onChange={(e) => setPrivateInfo({ ...privateInfo, maritalStatus: e.target.value })}
                    disabled={isFieldDisabled}
                    className="max-w-md disabled:opacity-70"
                  />
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-1">Date of Joining</p>
                  <Input
                    value={privateInfo.dateOfJoining}
                    onChange={(e) => setPrivateInfo({ ...privateInfo, dateOfJoining: e.target.value })}
                    disabled={isFieldDisabled}
                    className="max-w-md disabled:opacity-70"
                  />
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-1">Personal Email</p>
                  <Input
                    value={privateInfo.personalEmail}
                    onChange={(e) => setPrivateInfo({ ...privateInfo, personalEmail: e.target.value })}
                    disabled={isFieldDisabled}
                    className="max-w-md disabled:opacity-70"
                  />
                </div>

                <div className="md:col-span-2">
                  <p className="text-sm text-muted-foreground mb-1">Address</p>
                  <Input
                    value={privateInfo.address}
                    onChange={(e) => setPrivateInfo({ ...privateInfo, address: e.target.value })}
                    disabled={isFieldDisabled}
                    className="max-w-full disabled:opacity-70"
                  />
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-border/40">
                <h3 className="text-xl font-bold text-foreground mb-6">Bank Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Account Number</p>
                    <Input
                      value={privateInfo.bankAccount}
                      onChange={(e) => setPrivateInfo({ ...privateInfo, bankAccount: e.target.value })}
                      disabled={isFieldDisabled}
                      className="max-w-md disabled:opacity-70"
                    />
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Bank Name</p>
                    <Input
                      value={privateInfo.bankName}
                      onChange={(e) => setPrivateInfo({ ...privateInfo, bankName: e.target.value })}
                      disabled={isFieldDisabled}
                      className="max-w-md disabled:opacity-70"
                    />
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground mb-1">IFSC Code</p>
                    <Input
                      value={privateInfo.ifsc}
                      onChange={(e) => setPrivateInfo({ ...privateInfo, ifsc: e.target.value })}
                      disabled={isFieldDisabled}
                      className="max-w-md disabled:opacity-70"
                    />
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground mb-1">PAN Number</p>
                    <Input
                      value={privateInfo.pan}
                      onChange={(e) => setPrivateInfo({ ...privateInfo, pan: e.target.value })}
                      disabled={isFieldDisabled}
                      className="max-w-md disabled:opacity-70"
                    />
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground mb-1">UAN Number</p>
                    <Input
                      value={privateInfo.uan}
                      onChange={(e) => setPrivateInfo({ ...privateInfo, uan: e.target.value })}
                      disabled={isFieldDisabled}
                      className="max-w-md disabled:opacity-70"
                    />
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Employee Code</p>
                    <Input
                      value={privateInfo.empCode}
                      onChange={(e) => setPrivateInfo({ ...privateInfo, empCode: e.target.value })}
                      disabled={isFieldDisabled}
                      className="max-w-md disabled:opacity-70"
                    />
                  </div>
                </div>
              </div>

              {userRole === "admin" && isEditingPrivateInfo && (
                <div className="mt-6 flex justify-end">
                  <Button onClick={() => setIsEditingPrivateInfo(false)} className="gap-2">
                    <Save className="w-4 h-4" />
                    Save Changes
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Salary Info Tab Content */}
        <TabsContent value="salary" className="mt-6">
          <div className="space-y-6">
            {/* Salary Summary Section */}
            <Card className="border-border/40 bg-card/50 backdrop-blur-sm">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-foreground mb-6">Salary Summary</h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Monthly Wage</p>
                    <p className="text-2xl font-bold text-primary">₹ 95,000</p>
                    <p className="text-xs text-muted-foreground">/ month</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Yearly Wage</p>
                    <p className="text-2xl font-bold text-primary">₹ 11,40,000</p>
                    <p className="text-xs text-muted-foreground">/ year</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Working Days</p>
                    <p className="text-2xl font-bold text-foreground">5</p>
                    <p className="text-xs text-muted-foreground">days / week</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Break Time</p>
                    <p className="text-2xl font-bold text-foreground">1</p>
                    <p className="text-xs text-muted-foreground">hour / day</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Salary Components and Deductions - Two Column Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Left Column - Salary Components */}
              <Card className="border-border/40 bg-card/50 backdrop-blur-sm">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-foreground mb-6">Salary Components</h3>
                  <div className="space-y-6">
                    {/* Basic Salary */}
                    <div className="pb-4 border-b border-border/40">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <p className="font-semibold text-foreground">Basic Salary</p>
                          <p className="text-xs text-muted-foreground mt-1">Base salary component</p>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-primary">₹ 50,000</p>
                          <p className="text-xs text-muted-foreground">/ month</p>
                        </div>
                      </div>
                      <Badge variant="secondary" className="bg-primary/10 text-primary">
                        52.63%
                      </Badge>
                    </div>

                    {/* House Rent Allowance */}
                    <div className="pb-4 border-b border-border/40">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <p className="font-semibold text-foreground">House Rent Allowance (HRA)</p>
                          <p className="text-xs text-muted-foreground mt-1">Housing cost support</p>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-primary">₹ 20,000</p>
                          <p className="text-xs text-muted-foreground">/ month</p>
                        </div>
                      </div>
                      <Badge variant="secondary" className="bg-primary/10 text-primary">
                        21.05%
                      </Badge>
                    </div>

                    {/* Standard Allowance */}
                    <div className="pb-4 border-b border-border/40">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <p className="font-semibold text-foreground">Standard Allowance</p>
                          <p className="text-xs text-muted-foreground mt-1">Fixed monthly allowance</p>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-primary">₹ 10,000</p>
                          <p className="text-xs text-muted-foreground">/ month</p>
                        </div>
                      </div>
                      <Badge variant="secondary" className="bg-primary/10 text-primary">
                        10.53%
                      </Badge>
                    </div>

                    {/* Performance Bonus */}
                    <div className="pb-4 border-b border-border/40">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <p className="font-semibold text-foreground">Performance Bonus</p>
                          <p className="text-xs text-muted-foreground mt-1">Based on performance metrics</p>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-primary">₹ 8,000</p>
                          <p className="text-xs text-muted-foreground">/ month</p>
                        </div>
                      </div>
                      <Badge variant="secondary" className="bg-primary/10 text-primary">
                        8.42%
                      </Badge>
                    </div>

                    {/* Leave Travel Allowance */}
                    <div className="pb-4 border-b border-border/40">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <p className="font-semibold text-foreground">Leave Travel Allowance (LTA)</p>
                          <p className="text-xs text-muted-foreground mt-1">Travel expense coverage</p>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-primary">₹ 4,000</p>
                          <p className="text-xs text-muted-foreground">/ month</p>
                        </div>
                      </div>
                      <Badge variant="secondary" className="bg-primary/10 text-primary">
                        4.21%
                      </Badge>
                    </div>

                    {/* Fixed Allowance */}
                    <div className="pb-4">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <p className="font-semibold text-foreground">Fixed Allowance</p>
                          <p className="text-xs text-muted-foreground mt-1">Additional fixed benefit</p>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-primary">₹ 3,000</p>
                          <p className="text-xs text-muted-foreground">/ month</p>
                        </div>
                      </div>
                      <Badge variant="secondary" className="bg-primary/10 text-primary">
                        3.16%
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Right Column - Provident Fund & Deductions */}
              <div className="space-y-6">
                {/* Provident Fund */}
                <Card className="border-border/40 bg-card/50 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold text-foreground mb-6">Provident Fund (PF)</h3>
                    <div className="space-y-6">
                      {/* Employee Contribution */}
                      <div className="pb-4 border-b border-border/40">
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex-1">
                            <p className="font-semibold text-foreground">Employee Contribution</p>
                            <p className="text-xs text-muted-foreground mt-1">Your PF contribution</p>
                          </div>
                          <div className="text-right">
                            <p className="text-lg font-bold text-destructive">₹ 6,000</p>
                            <p className="text-xs text-muted-foreground">/ month</p>
                          </div>
                        </div>
                        <Badge variant="secondary" className="bg-destructive/10 text-destructive">
                          12% of Basic
                        </Badge>
                      </div>

                      {/* Employer Contribution */}
                      <div className="pb-4">
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex-1">
                            <p className="font-semibold text-foreground">Employer Contribution</p>
                            <p className="text-xs text-muted-foreground mt-1">Company's PF contribution</p>
                          </div>
                          <div className="text-right">
                            <p className="text-lg font-bold text-green-500">₹ 6,000</p>
                            <p className="text-xs text-muted-foreground">/ month</p>
                          </div>
                        </div>
                        <Badge variant="secondary" className="bg-green-500/10 text-green-500">
                          12% of Basic
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Tax Deductions */}
                <Card className="border-border/40 bg-card/50 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold text-foreground mb-6">Tax Deductions</h3>
                    <div className="space-y-6">
                      {/* Professional Tax */}
                      <div className="pb-4">
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex-1">
                            <p className="font-semibold text-foreground">Professional Tax</p>
                            <p className="text-xs text-muted-foreground mt-1">State-mandated tax deduction</p>
                          </div>
                          <div className="text-right">
                            <p className="text-lg font-bold text-destructive">₹ 200</p>
                            <p className="text-xs text-muted-foreground">/ month</p>
                          </div>
                        </div>
                      </div>

                      {/* Income Tax (TDS) */}
                      <div className="pb-4">
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex-1">
                            <p className="font-semibold text-foreground">Income Tax (TDS)</p>
                            <p className="text-xs text-muted-foreground mt-1">Tax deducted at source</p>
                          </div>
                          <div className="text-right">
                            <p className="text-lg font-bold text-destructive">₹ 8,800</p>
                            <p className="text-xs text-muted-foreground">/ month</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Net Salary */}
                <Card className="border-primary/40 bg-primary/5 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm text-muted-foreground mb-1">Net Take Home</p>
                        <p className="text-xs text-muted-foreground">After all deductions</p>
                      </div>
                      <div className="text-right">
                        <p className="text-3xl font-bold text-primary">₹ 80,000</p>
                        <p className="text-xs text-muted-foreground">/ month</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
