"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, ChevronLeft, ChevronRight } from "lucide-react"

// Mock attendance data
const mockAttendanceData = [
  {
    id: 1,
    employee: "John Doe",
    checkIn: "09:00",
    checkOut: "18:00",
    workHours: "09:00",
    extraHours: "00:00",
  },
  {
    id: 2,
    employee: "Jane Smith",
    checkIn: "08:45",
    checkOut: "17:45",
    workHours: "09:00",
    extraHours: "00:00",
  },
  {
    id: 3,
    employee: "Michael Johnson",
    checkIn: "09:15",
    checkOut: "19:00",
    workHours: "09:00",
    extraHours: "00:45",
  },
  {
    id: 4,
    employee: "Emily Davis",
    checkIn: "10:00",
    checkOut: "19:00",
    workHours: "09:00",
    extraHours: "00:00",
  },
  {
    id: 5,
    employee: "Chris Wilson",
    checkIn: "08:30",
    checkOut: "18:30",
    workHours: "09:00",
    extraHours: "01:00",
  },
  {
    id: 6,
    employee: "Sarah Brown",
    checkIn: "09:00",
    checkOut: "18:00",
    workHours: "09:00",
    extraHours: "00:00",
  },
  {
    id: 7,
    employee: "David Martinez",
    checkIn: "09:30",
    checkOut: "18:30",
    workHours: "09:00",
    extraHours: "00:00",
  },
  {
    id: 8,
    employee: "Lisa Anderson",
    checkIn: "08:00",
    checkOut: "19:00",
    workHours: "09:00",
    extraHours: "02:00",
  },
  {
    id: 9,
    employee: "Robert Taylor",
    checkIn: "09:00",
    checkOut: "18:15",
    workHours: "09:00",
    extraHours: "00:15",
  },
  {
    id: 10,
    employee: "Amanda White",
    checkIn: "10:30",
    checkOut: "19:30",
    workHours: "09:00",
    extraHours: "00:00",
  },
]

export default function AttendanceListView() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedDate, setSelectedDate] = useState("22 October 2025")
  const [viewMode, setViewMode] = useState("Day")

  // Filter employees based on search query
  const filteredAttendance = mockAttendanceData.filter((record) =>
    record.employee.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  // Mock date navigation
  const handlePreviousDate = () => {
    console.log("[v0] Navigating to previous date")
    // In a real app, this would update the date state and fetch new data
  }

  const handleNextDate = () => {
    console.log("[v0] Navigating to next date")
    // In a real app, this would update the date state and fetch new data
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header Section */}
      <div className="px-8 py-6 border-b border-border/50">
        <div className="flex flex-col gap-6 max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-foreground">Attendance</h1>

          {/* Search Bar */}
          <div className="relative max-w-xl mx-auto w-full">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search employees..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 h-11 bg-card border-border/50"
            />
          </div>
        </div>
      </div>

      {/* Controls Row */}
      <div className="px-8 py-4 border-b border-border/50">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            <Button variant="outline" size="icon" onClick={handlePreviousDate} className="h-9 w-9 bg-transparent">
              <ChevronLeft className="w-5 h-5" />
            </Button>

            <Select value={selectedDate} onValueChange={setSelectedDate}>
              <SelectTrigger className="w-[200px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="20 October 2025">20 October 2025</SelectItem>
                <SelectItem value="21 October 2025">21 October 2025</SelectItem>
                <SelectItem value="22 October 2025">22 October 2025</SelectItem>
                <SelectItem value="23 October 2025">23 October 2025</SelectItem>
                <SelectItem value="24 October 2025">24 October 2025</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline" size="icon" onClick={handleNextDate} className="h-9 w-9 bg-transparent">
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>

          <Button variant="outline" className="h-9 px-6 bg-transparent">
            {viewMode}
          </Button>
        </div>
      </div>

      {/* Attendance Table */}
      <div className="flex-1 overflow-auto px-8 py-6">
        <Card className="max-w-7xl mx-auto overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="font-semibold text-foreground">Employee</TableHead>
                <TableHead className="font-semibold text-foreground">Check In</TableHead>
                <TableHead className="font-semibold text-foreground">Check Out</TableHead>
                <TableHead className="font-semibold text-foreground">Work Hours</TableHead>
                <TableHead className="font-semibold text-foreground">Extra Hours</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAttendance.length > 0 ? (
                filteredAttendance.map((record) => (
                  <TableRow key={record.id}>
                    <TableCell className="font-medium">{record.employee}</TableCell>
                    <TableCell className="text-muted-foreground">{record.checkIn}</TableCell>
                    <TableCell className="text-muted-foreground">{record.checkOut}</TableCell>
                    <TableCell className="text-muted-foreground">{record.workHours}</TableCell>
                    <TableCell>
                      <span
                        className={
                          record.extraHours !== "00:00" ? "text-primary font-semibold" : "text-muted-foreground"
                        }
                      >
                        {record.extraHours}
                      </span>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                    No employees found matching your search.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </Card>
      </div>
    </div>
  )
}
