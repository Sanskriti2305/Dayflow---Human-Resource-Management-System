"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { User, Mail, Phone, MapPin, FileText } from "lucide-react"

export default function ProfileSection() {
  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-white">My Profile</h2>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Card */}
        <Card className="lg:col-span-1 bg-slate-900 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Profile Picture</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="w-32 h-32 mx-auto bg-gradient-to-br from-cyan-600 to-cyan-400 rounded-lg flex items-center justify-center">
              <User className="w-16 h-16 text-white" />
            </div>
            <Button className="w-full bg-cyan-600 hover:bg-cyan-700">Upload Photo</Button>
          </CardContent>
        </Card>

        {/* Personal Details */}
        <Card className="lg:col-span-2 bg-slate-900 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Personal Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-slate-300">First Name</label>
                <Input defaultValue="John" className="bg-slate-800 border-slate-700 text-white mt-1" />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-300">Last Name</label>
                <Input defaultValue="Doe" className="bg-slate-800 border-slate-700 text-white mt-1" />
              </div>
              <div className="col-span-2">
                <label className="text-sm font-medium text-slate-300">Email</label>
                <div className="flex items-center gap-2 mt-1">
                  <Mail className="w-5 h-5 text-slate-400" />
                  <Input
                    defaultValue="john.doe@company.com"
                    disabled
                    className="bg-slate-800 border-slate-700 text-slate-400 mt-0"
                  />
                </div>
              </div>
              <div className="col-span-2">
                <label className="text-sm font-medium text-slate-300">Phone</label>
                <div className="flex items-center gap-2 mt-1">
                  <Phone className="w-5 h-5 text-slate-400" />
                  <Input defaultValue="+1 (555) 000-1234" className="bg-slate-800 border-slate-700 text-white mt-0" />
                </div>
              </div>
              <div className="col-span-2">
                <label className="text-sm font-medium text-slate-300">Address</label>
                <div className="flex items-center gap-2 mt-1">
                  <MapPin className="w-5 h-5 text-slate-400" />
                  <Input
                    defaultValue="123 Main St, New York, NY"
                    className="bg-slate-800 border-slate-700 text-white mt-0"
                  />
                </div>
              </div>
            </div>
            <Button className="bg-cyan-600 hover:bg-cyan-700">Save Changes</Button>
          </CardContent>
        </Card>
      </div>

      {/* Job Details */}
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Job Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <p className="text-sm text-slate-400">Department</p>
              <p className="text-lg font-semibold text-white mt-1">Engineering</p>
            </div>
            <div>
              <p className="text-sm text-slate-400">Position</p>
              <p className="text-lg font-semibold text-white mt-1">Senior Developer</p>
            </div>
            <div>
              <p className="text-sm text-slate-400">Employee ID</p>
              <p className="text-lg font-semibold text-white mt-1">EMP-2024-001</p>
            </div>
            <div>
              <p className="text-sm text-slate-400">Joining Date</p>
              <p className="text-lg font-semibold text-white mt-1">Jan 15, 2023</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Documents */}
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Documents
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {["ID Verification", "Contract", "Insurance Form"].map((doc) => (
              <div key={doc} className="flex items-center justify-between p-3 bg-slate-800 rounded-lg">
                <span className="text-slate-300">{doc}</span>
                <Button variant="ghost" size="sm" className="text-cyan-400 hover:text-cyan-300">
                  Download
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
