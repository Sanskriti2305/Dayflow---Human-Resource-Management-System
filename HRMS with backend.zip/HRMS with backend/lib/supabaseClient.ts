import { createClient } from '@supabase/supabase-js';

const supabaseUrl = "https://rjkhqblqqrokcabiikzr.supabase.co";
const supabaseAnonKey = "sb_publishable_j-e3zXE2yezIo9spEKjVIw_DFXgVGr3";

export const supabase = createClient(
  supabaseUrl,
  supabaseAnonKey
);
