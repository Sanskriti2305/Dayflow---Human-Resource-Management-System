"use client"

import { useEffect, useState } from "react"
import { supabase } from "@/lib/supabaseClient"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, Plus } from "lucide-react"

interface Employee {
  id: string
  name: string
}

interface EmployeeGridSectionProps {
  role?: "employee" | "admin"
}

export default function EmployeeGridSection({ role = "employee" }: EmployeeGridSectionProps) {
  const [employees, setEmployees] = useState<Employee[]>([])
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null)

  // 🔄 FETCH REAL EMPLOYEES FROM SUPABASE
  useEffect(() => {
    fetchEmployees()
  }, [])

  const fetchEmployees = async () => {
    const { data, error } = await supabase
      .from("users")
      .select("id, name")
      .eq("role", "employee")
      .order("name", { ascending: true })

    if (error) {
      console.error(error)
      alert("Failed to load employees")
      return
    }

    setEmployees(data || [])
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      {role === "admin" && (
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Search employees..."
              className="pl-10 bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
            />
          </div>
          <Button className="bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-semibold">
            <Plus className="w-4 h-4 mr-2" />
            NEW
          </Button>
        </div>
      )}

      {/* Employee Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {employees.length === 0 && (
          <p className="text-slate-400 col-span-full text-center">
            No employees found
          </p>
        )}

        {employees.map((employee) => (
          <Card
            key={employee.id}
            className="bg-white border border-gray-200 cursor-pointer hover:border-gray-400 transition"
            onClick={() => setSelectedEmployee(employee)}
          >
            <CardContent className="p-6">
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 bg-gray-200 rounded flex items-center justify-center mb-3">
                  <span className="text-gray-600 font-semibold text-lg">
                    {(employee.name ?? "NA")
                      .split(" ")
                      .map((n) => n[0])
                      .join("")
                      .slice(0, 2)
                      .toUpperCase()}
                  </span>
                </div>
                <h3 className="text-gray-900 font-medium text-center">
                  {employee.name}
                </h3>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Employee Detail Modal */}
      {selectedEmployee && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <Card className="bg-white border border-gray-200 w-full max-w-md">
            <CardContent className="p-6 space-y-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold text-gray-900">
                  {selectedEmployee.name}
                </h3>
                <button
                  onClick={() => setSelectedEmployee(null)}
                  className="text-gray-400 hover:text-gray-900"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-2 text-sm text-gray-700">
                <p>
                  <span className="font-semibold">Employee ID:</span>{" "}
                  {selectedEmployee.id}
                </p>
                <p>
                  <span className="font-semibold">Role:</span> Employee
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
