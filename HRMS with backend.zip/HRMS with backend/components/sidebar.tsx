"use client"

import type { LucideIcon } from "lucide-react"

interface MenuItem {
  id: string
  label: string
  icon: LucideIcon
}

interface SidebarProps {
  menuItems: MenuItem[]
  activeSection: string
  onSectionChange: (section: string) => void
}

export default function Sidebar({ menuItems, activeSection, onSectionChange }: SidebarProps) {
  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-slate-900 border-r border-slate-700 p-6">
      <div className="mb-8">
        <h2 className="text-xl font-bold text-white">Dayflow</h2>
        <p className="text-xs text-slate-400 mt-1">HR Management System</p>
      </div>

      <nav className="space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon
          const isActive = activeSection === item.id

          return (
            <button
              key={item.id}
              onClick={() => onSectionChange(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg font-medium transition-colors ${
                isActive ? "bg-cyan-600 text-white" : "text-slate-300 hover:bg-slate-800"
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          )
        })}
      </nav>
    </aside>
  )
}
