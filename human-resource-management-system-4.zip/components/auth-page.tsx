"use client"

import type React from "react"
import Image from "next/image"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"

interface AuthPageProps {
  onLogin: (role: "employee" | "admin") => void
}

export default function AuthPage({ onLogin }: AuthPageProps) {
  const [isSignup, setIsSignup] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [selectedRole, setSelectedRole] = useState<"employee" | "admin">("employee")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email && password) {
      onLogin(selectedRole)
    }
  }

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-zinc-950 border-zinc-800 shadow-[0_0_50px_rgba(0,0,0,1)]">
        <CardHeader className="space-y-2">
          <div className="flex flex-col items-center justify-center gap-4 mb-6">
            <div className="relative w-20 h-20 overflow-hidden rounded-2xl shadow-[0_0_30px_rgba(34,197,94,0.15)]">
              <Image src="/logo.jpg" alt="Dayflow Logo" fill className="object-cover" />
            </div>
            <h1 className="text-3xl font-bold text-white tracking-tighter">Dayflow</h1>
          </div>
          <CardTitle className="text-white">{isSignup ? "Create Account" : "Welcome Back"}</CardTitle>
          <CardDescription className="text-slate-400">
            {isSignup ? "Register to get started" : "Sign in to your account"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-200">Email</label>
              <Input
                type="email"
                placeholder="your@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-200">Password</label>
              <Input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-slate-800 border-slate-700 text-white placeholder:text-slate-500"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-200">Role</label>
              <div className="flex gap-2">
                <Button
                  type="button"
                  onClick={() => setSelectedRole("employee")}
                  variant={selectedRole === "employee" ? "default" : "outline"}
                  className={
                    selectedRole === "employee" ? "bg-cyan-600 hover:bg-cyan-700" : "border-slate-600 text-slate-300"
                  }
                >
                  Employee
                </Button>
                <Button
                  type="button"
                  onClick={() => setSelectedRole("admin")}
                  variant={selectedRole === "admin" ? "default" : "outline"}
                  className={
                    selectedRole === "admin" ? "bg-cyan-600 hover:bg-cyan-700" : "border-slate-600 text-slate-300"
                  }
                >
                  HR Admin
                </Button>
              </div>
            </div>

            <Button type="submit" className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-semibold">
              {isSignup ? "Sign Up" : "Sign In"}
            </Button>
          </form>

          <div className="mt-4 text-center">
            <button
              onClick={() => setIsSignup(!isSignup)}
              className="text-sm text-cyan-400 hover:text-cyan-300 font-medium"
            >
              {isSignup ? "Already have an account? Sign in" : "Don't have an account? Sign up"}
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
