"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Plus, Upload, X, Search } from "lucide-react"
import { Input } from "@/components/ui/input"

type LeaveType = "Paid Time Off" | "Sick Leave" | "Unpaid Leave"
type LeaveStatus = "Pending" | "Approved" | "Rejected"

interface LeaveRequest {
  id: number
  employeeName: string
  startDate: string
  endDate: string
  type: LeaveType
  status: LeaveStatus
  reason?: string
}

export default function AdminTimeOffSection() {
  const [activeTab, setActiveTab] = useState<"timeoff" | "allocation">("timeoff")
  const [showModal, setShowModal] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>([
    {
      id: 1,
      employeeName: "John Doe",
      startDate: "28/10/2025",
      endDate: "28/10/2025",
      type: "Paid Time Off",
      status: "Pending",
      reason: "Personal matters",
    },
    {
      id: 2,
      employeeName: "Jane Smith",
      startDate: "25/10/2025",
      endDate: "27/10/2025",
      type: "Sick Leave",
      status: "Pending",
      reason: "Medical appointment",
    },
    {
      id: 3,
      employeeName: "Mike Johnson",
      startDate: "01/11/2025",
      endDate: "05/11/2025",
      type: "Unpaid Leave",
      status: "Approved",
      reason: "Family emergency",
    },
    {
      id: 4,
      employeeName: "Sarah Williams",
      startDate: "15/11/2025",
      endDate: "16/11/2025",
      type: "Paid Time Off",
      status: "Pending",
      reason: "Family event",
    },
    {
      id: 5,
      employeeName: "Robert Brown",
      startDate: "20/11/2025",
      endDate: "20/11/2025",
      type: "Sick Leave",
      status: "Rejected",
      reason: "Medical checkup",
    },
  ])
  const [formData, setFormData] = useState({
    employee: "",
    timeOffType: "Paid Time Off" as LeaveType,
    startDate: "",
    endDate: "",
    allocation: "1.00",
    attachment: null as File | null,
  })

  const filteredRequests = searchQuery
    ? leaveRequests.filter((req) => req.employeeName.toLowerCase().includes(searchQuery.toLowerCase()))
    : leaveRequests

  const handleApprove = (id: number) => {
    setLeaveRequests((prev) => prev.map((req) => (req.id === id ? { ...req, status: "Approved" as LeaveStatus } : req)))
  }

  const handleReject = (id: number) => {
    setLeaveRequests((prev) => prev.map((req) => (req.id === id ? { ...req, status: "Rejected" as LeaveStatus } : req)))
  }

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <h2 className="text-2xl font-semibold text-white">Time Off</h2>

        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab("timeoff")}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === "timeoff"
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              }`}
            >
              Time Off
            </button>
            <button
              onClick={() => setActiveTab("allocation")}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === "allocation"
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              }`}
            >
              Allocation
            </button>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input
                type="text"
                placeholder="Search employees..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-slate-800 border-slate-700 text-white w-64"
              />
            </div>
            <Button
              onClick={() => setShowModal(true)}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              <Plus className="w-4 h-4 mr-2" />
              New
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="border border-slate-700 rounded-lg p-6 bg-slate-900/50">
          <p className="text-primary font-semibold mb-2 text-sm uppercase tracking-wide">Paid Time Off</p>
          <p className="text-white text-2xl font-bold">24 Days Available</p>
        </div>
        <div className="border border-slate-700 rounded-lg p-6 bg-slate-900/50">
          <p className="text-primary font-semibold mb-2 text-sm uppercase tracking-wide">Sick Time Off</p>
          <p className="text-white text-2xl font-bold">07 Days Available</p>
        </div>
      </div>

      <div className="border border-slate-700 rounded-lg overflow-hidden bg-slate-900">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-700 bg-slate-800">
                <th className="text-left py-3 px-4 text-slate-300 font-semibold">Employee Name</th>
                <th className="text-left py-3 px-4 text-slate-300 font-semibold">Start Date</th>
                <th className="text-left py-3 px-4 text-slate-300 font-semibold">End Date</th>
                <th className="text-left py-3 px-4 text-slate-300 font-semibold">Time Off Type</th>
                <th className="text-left py-3 px-4 text-slate-300 font-semibold">Status</th>
                <th className="text-left py-3 px-4 text-slate-300 font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredRequests.map((request) => (
                <tr key={request.id} className="border-b border-slate-800 hover:bg-slate-800/50 transition">
                  <td className="py-3 px-4 text-slate-200 font-medium">{request.employeeName}</td>
                  <td className="py-3 px-4 text-slate-300">{request.startDate}</td>
                  <td className="py-3 px-4 text-slate-300">{request.endDate}</td>
                  <td className="py-3 px-4">
                    <span className="text-primary font-medium">{request.type}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-3 py-1 text-xs rounded-full font-semibold ${
                        request.status === "Pending"
                          ? "bg-yellow-900/50 text-yellow-300 border border-yellow-700"
                          : request.status === "Approved"
                            ? "bg-green-900/50 text-green-300 border border-green-700"
                            : "bg-red-900/50 text-red-300 border border-red-700"
                      }`}
                    >
                      {request.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    {request.status === "Pending" && (
                      <div className="flex gap-2">
                        <Button
                          onClick={() => handleApprove(request.id)}
                          size="sm"
                          className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 h-8"
                        >
                          Approve
                        </Button>
                        <Button
                          onClick={() => handleReject(request.id)}
                          size="sm"
                          variant="destructive"
                          className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 h-8"
                        >
                          Reject
                        </Button>
                      </div>
                    )}
                    {request.status !== "Pending" && (
                      <span className="text-slate-500 text-xs">No actions available</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {filteredRequests.length === 0 && (
        <div className="text-center py-12 text-slate-400">No time off requests found.</div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-slate-900 border border-slate-600 rounded-lg p-8 w-full max-w-md">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-white text-lg font-semibold">Time Off Request</h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-slate-300 text-sm block mb-1">Employee</label>
                <Input
                  type="text"
                  value={formData.employee}
                  onChange={(e) => setFormData({ ...formData, employee: e.target.value })}
                  placeholder="Enter employee name"
                  className="bg-slate-800 border border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="text-slate-300 text-sm block mb-1">Time Off Type</label>
                <select
                  value={formData.timeOffType}
                  onChange={(e) => setFormData({ ...formData, timeOffType: e.target.value as LeaveType })}
                  className="w-full bg-slate-800 border border-slate-700 rounded text-cyan-400 p-2"
                >
                  <option>Paid Time Off</option>
                  <option>Sick Leave</option>
                  <option>Unpaid Leave</option>
                </select>
              </div>

              <div>
                <label className="text-slate-300 text-sm block mb-1">Validity Period</label>
                <div className="flex gap-2 items-center">
                  <input
                    type="date"
                    value={formData.startDate}
                    onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                    className="flex-1 bg-slate-800 border border-slate-700 rounded text-slate-300 p-2 text-sm"
                  />
                  <span className="text-slate-400">→</span>
                  <input
                    type="date"
                    value={formData.endDate}
                    onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                    className="flex-1 bg-slate-800 border border-slate-700 rounded text-slate-300 p-2 text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 text-sm block mb-1">Allocation</label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    step="0.5"
                    value={formData.allocation}
                    onChange={(e) => setFormData({ ...formData, allocation: e.target.value })}
                    className="flex-1 bg-slate-800 border border-slate-700 rounded text-white p-2"
                  />
                  <span className="text-slate-400 flex items-center">Days</span>
                </div>
              </div>

              <div>
                <label className="text-slate-300 text-sm block mb-1">
                  Attachment {formData.timeOffType === "Sick Leave" && <span className="text-red-400">*</span>}
                </label>
                <p className="text-xs text-slate-400 mb-2">
                  {formData.timeOffType === "Sick Leave" ? "Required for sick leave" : "Optional"}
                </p>
                <label className="cursor-pointer">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 bg-cyan-600 rounded flex items-center justify-center hover:bg-cyan-700 transition">
                      <Upload className="w-5 h-5 text-white" />
                    </div>
                    {formData.attachment && <span className="text-slate-300 text-sm">{formData.attachment.name}</span>}
                  </div>
                  <input
                    type="file"
                    className="hidden"
                    onChange={(e) => setFormData({ ...formData, attachment: e.target.files?.[0] || null })}
                  />
                </label>
              </div>

              <div className="flex gap-3 pt-4">
                <Button className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground">Submit</Button>
                <Button
                  onClick={() => setShowModal(false)}
                  variant="outline"
                  className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-800"
                >
                  Discard
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
