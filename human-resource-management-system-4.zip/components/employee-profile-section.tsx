"use client"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useState } from "react"

export default function EmployeeProfileSection() {
  const [activeTab, setActiveTab] = useState<"resume" | "private" | "salary" | "security">("resume")

  const tabs = [
    { id: "resume", label: "Resume" },
    { id: "private", label: "Private Info" },
    { id: "salary", label: "Salary Info" },
    { id: "security", label: "Security" },
  ]

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-white">My Profile</h2>

      {/* Profile Header */}
      <Card className="bg-slate-900 border-slate-700">
        <CardContent className="p-6">
          <div className="flex gap-6 items-start">
            <div className="w-32 h-32 bg-gradient-to-br from-red-600 to-red-400 rounded-full flex items-center justify-center flex-shrink-0 border-4 border-slate-800">
              <span className="text-4xl text-white font-bold">JD</span>
            </div>

            <div className="flex-1 grid grid-cols-2 gap-6">
              <div>
                <p className="text-slate-400 text-sm">Name</p>
                <p className="text-white font-semibold">John Doe</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm">Company</p>
                <p className="text-white font-semibold">Odeo India</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm">Job Position</p>
                <p className="text-white font-semibold">Developer</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm">Department</p>
                <p className="text-white font-semibold">Engineering</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm">Email</p>
                <p className="text-white font-semibold">john.doe@odeo.com</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm">Manager</p>
                <p className="text-white font-semibold">Jane Smith</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm">Mobile</p>
                <p className="text-white font-semibold">+91 98765 43210</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm">Location</p>
                <p className="text-white font-semibold">New Delhi</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <div className="flex gap-4 border-b border-slate-700">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
              activeTab === tab.id
                ? "border-cyan-400 text-cyan-400"
                : "border-transparent text-slate-400 hover:text-slate-300"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === "resume" && (
        <Card className="bg-slate-900 border-slate-700">
          <CardContent className="p-6 space-y-6">
            <div className="grid grid-cols-2 gap-8">
              <div className="space-y-4">
                <h3 className="text-white font-bold">About</h3>
                <p className="text-slate-300 text-sm">
                  Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                </p>

                <h3 className="text-white font-bold mt-6">Skills</h3>
                <div className="space-y-2">
                  <p className="text-slate-300 text-sm">• React Development</p>
                  <p className="text-slate-300 text-sm">• JavaScript</p>
                  <p className="text-slate-300 text-sm">• Full Stack Development</p>
                </div>

                <h3 className="text-white font-bold mt-6">What I love about my job</h3>
                <p className="text-slate-300 text-sm">
                  Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                </p>
              </div>

              <div className="space-y-4">
                <h3 className="text-white font-bold">Certifications</h3>
                <p className="text-slate-300 text-sm">AWS Certified Developer</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === "private" && (
        <Card className="bg-slate-900 border-slate-700">
          <CardContent className="p-6 space-y-4">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="text-slate-400 text-sm">Date of Birth</label>
                <Input
                  defaultValue="15-05-1990"
                  disabled
                  className="bg-slate-800 border-slate-700 text-slate-400 mt-2"
                />
              </div>
              <div>
                <label className="text-slate-400 text-sm">Bank Details</label>
              </div>
              <div>
                <label className="text-slate-400 text-sm">Residing Address</label>
                <Input
                  defaultValue="123 Main St, New Delhi"
                  disabled
                  className="bg-slate-800 border-slate-700 text-slate-400 mt-2"
                />
              </div>
              <div>
                <label className="text-slate-400 text-sm">Account Number</label>
                <Input
                  defaultValue="1234567890"
                  disabled
                  className="bg-slate-800 border-slate-700 text-slate-400 mt-2"
                />
              </div>
              <div>
                <label className="text-slate-400 text-sm">Nationality</label>
                <Input defaultValue="Indian" disabled className="bg-slate-800 border-slate-700 text-slate-400 mt-2" />
              </div>
              <div>
                <label className="text-slate-400 text-sm">Bank Name</label>
                <Input
                  defaultValue="HDFC Bank"
                  disabled
                  className="bg-slate-800 border-slate-700 text-slate-400 mt-2"
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === "salary" && (
        <Card className="bg-slate-900 border-slate-700">
          <CardContent className="p-6 space-y-4">
            <p className="text-slate-300 text-sm">Salary information is only visible to admin users.</p>
            <div className="space-y-2 text-slate-300">
              <div className="flex justify-between">
                <span>Monthly Salary:</span>
                <span className="font-semibold">₹ 50,000</span>
              </div>
              <div className="flex justify-between">
                <span>Yearly Salary:</span>
                <span className="font-semibold">₹ 6,00,000</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === "security" && (
        <Card className="bg-slate-900 border-slate-700">
          <CardContent className="p-6">
            <p className="text-slate-300">Security settings coming soon...</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
