"use client"

import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { useState } from "react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function EmployeeAttendanceSection() {
  const currentDate = new Date()
  const [selectedMonth, setSelectedMonth] = useState(currentDate.getMonth())
  const [selectedYear, setSelectedYear] = useState(currentDate.getFullYear())
  const [currentDay, setCurrentDay] = useState(currentDate.getDate())

  const attendanceRecords = [
    {
      date: "01/01/2025",
      checkIn: "09:00 AM",
      checkOut: "06:00 PM",
      workHours: "8.5h",
      extraHours: "0.5h",
    },
    {
      date: "02/01/2025",
      checkIn: "08:55 AM",
      checkOut: "05:55 PM",
      workHours: "8.75h",
      extraHours: "0.75h",
    },
    {
      date: "03/01/2025",
      checkIn: "09:10 AM",
      checkOut: "06:15 PM",
      workHours: "8.5h",
      extraHours: "0.5h",
    },
    {
      date: "06/01/2025",
      checkIn: "09:05 AM",
      checkOut: "06:00 PM",
      workHours: "8.75h",
      extraHours: "0.75h",
    },
    {
      date: "07/01/2025",
      checkIn: "09:00 AM",
      checkOut: "06:10 PM",
      workHours: "8.6h",
      extraHours: "0.6h",
    },
  ]

  const presentDays = attendanceRecords.length
  const leavesDays = 2
  const totalWorkingDays = 22

  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ]

  const handlePreviousDay = () => {
    setCurrentDay((prev) => Math.max(1, prev - 1))
  }

  const handleNextDay = () => {
    setCurrentDay((prev) => Math.min(31, prev + 1))
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 flex-wrap">
        <Button
          variant="outline"
          size="icon"
          onClick={handlePreviousDay}
          className="bg-white border-gray-300 text-gray-700 hover:bg-gray-100"
        >
          <ChevronLeft className="w-4 h-4" />
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={handleNextDay}
          className="bg-white border-gray-300 text-gray-700 hover:bg-gray-100"
        >
          <ChevronRight className="w-4 h-4" />
        </Button>
        <Select value={months[selectedMonth]} onValueChange={(val) => setSelectedMonth(months.indexOf(val))}>
          <SelectTrigger className="w-40 bg-white border-gray-300 text-gray-900">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {months.map((month, index) => (
              <SelectItem key={month} value={month}>
                {month}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="flex gap-4 ml-auto">
          <div className="px-4 py-2 bg-green-100 text-green-700 rounded-lg border border-green-300">
            <span className="font-semibold">{presentDays}</span> Days Present
          </div>
          <div className="px-4 py-2 bg-blue-100 text-blue-700 rounded-lg border border-blue-300">
            <span className="font-semibold">{leavesDays}</span> Leaves
          </div>
          <div className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg border border-gray-300">
            <span className="font-semibold">{totalWorkingDays}</span> Total Working Days
          </div>
        </div>
      </div>

      <div className="border border-gray-200 rounded-lg overflow-hidden bg-white">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-200 bg-gray-50">
              <th className="text-left py-3 px-4 text-gray-700 font-semibold">Date</th>
              <th className="text-left py-3 px-4 text-gray-700 font-semibold">Check In</th>
              <th className="text-left py-3 px-4 text-gray-700 font-semibold">Check Out</th>
              <th className="text-left py-3 px-4 text-gray-700 font-semibold">Work Hours</th>
              <th className="text-left py-3 px-4 text-gray-700 font-semibold">Extra Hours</th>
            </tr>
          </thead>
          <tbody>
            {attendanceRecords.map((record, index) => (
              <tr key={index} className="border-b border-gray-200 hover:bg-gray-50">
                <td className="py-3 px-4 text-gray-900">{record.date}</td>
                <td className="py-3 px-4 text-gray-700">{record.checkIn}</td>
                <td className="py-3 px-4 text-gray-700">{record.checkOut}</td>
                <td className="py-3 px-4 text-gray-700">{record.workHours}</td>
                <td className="py-3 px-4 text-gray-700">{record.extraHours}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {attendanceRecords.length === 0 && (
        <div className="text-center py-8 text-gray-500">No attendance records for this period.</div>
      )}
    </div>
  )
}
