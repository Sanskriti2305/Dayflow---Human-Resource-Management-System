"use client"

//add this
import { supabase } from "@/lib/supabaseClient"
//then change handleSubmit
import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Image from "next/image"

interface SignInPageProps {
  onLogin: (role: "employee" | "admin") => void
  onSwitchToSignup: () => void
}

export default function SignInPage({ onLogin, onSwitchToSignup }: SignInPageProps) {
  const [role, setRole] = useState<"employee" | "admin">("employee")
  const [loginId, setLoginId] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)

  //change this
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // 1️⃣ Authenticate user
    const { data, error } = await supabase.auth.signInWithPassword({
      email: loginId,
      password,
    })

    if (error) {
      alert(error.message)
      return
    }

    const user = data.user
    if (!user) {
      alert("User not found")
      return
    }

    // 2️⃣ Fetch REAL role from database
    const { data: profile, error: profileError } = await supabase
      .from("users")
      .select("role")
      .eq("auth_id", user.id)
      .single()

    if (profileError) {
      alert(profileError.message)
      await supabase.auth.signOut()
      return
    }

    // 3️⃣ Validate UI role vs DB role
    if (profile.role.toLowerCase() !== role.toLowerCase()) {
      alert(`Access denied. You are registered as ${profile.role}.`)
      await supabase.auth.signOut()
      return
    }

    // 4️⃣ Role matches → allow login
    onLogin(profile.role)
  }



  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md border-2 border-slate-600 rounded-lg p-8 bg-slate-950">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="text-xl font-light text-slate-400 mb-6">Sign in Page</div>
          <div className="flex justify-center">
            <Image src="/company-logo.jpg" alt="Company Logo" width={120} height={120} className="rounded-lg" />
          </div>
        </div>

        <div className="flex gap-4 mb-8 justify-center">
          <button
            onClick={() => setRole("employee")}
            className={`px-6 py-2 rounded font-light transition ${
              role === "employee"
                ? "bg-cyan-500 text-slate-950"
                : "border-2 border-slate-500 text-slate-400 hover:border-slate-400"
            }`}
          >
            Employee
          </button>
          <button
            onClick={() => setRole("admin")}
            className={`px-6 py-2 rounded font-light transition ${
              role === "admin"
                ? "bg-cyan-500 text-slate-950"
                : "border-2 border-slate-500 text-slate-400 hover:border-slate-400"
            }`}
          >
            Admin
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Login ID */}
          <div className="space-y-2">
            <label className="text-slate-300 font-light">Login ID/Email :-</label>
            <Input
              type="text"
              placeholder=""
              value={loginId}
              onChange={(e) => setLoginId(e.target.value)}
              className="bg-slate-950 border-slate-500 text-slate-200 placeholder:text-slate-600 rounded"
            />
          </div>

          {/* Password */}
          <div className="space-y-2">
            <label className="text-slate-300 font-light">Password :-</label>
            <Input
              type={showPassword ? "text" : "password"}
              placeholder=""
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-slate-950 border-slate-500 text-slate-200 placeholder:text-slate-600 rounded"
            />
          </div>

          {/* Sign In Button */}
          <Button
            type="submit"
            className="w-full bg-purple-600 hover:bg-purple-700 text-slate-950 font-semibold py-2 rounded"
          >
            SIGN IN
          </Button>
        </form>

        {/* Footer Link */}
        <div className="text-center mt-6">
          <button
            onClick={onSwitchToSignup}
            className="text-slate-400 text-sm font-light hover:text-slate-300 transition"
          >
            Don't have an Account? Sign Up
          </button>
        </div>
      </div>
    </div>
  )
}
