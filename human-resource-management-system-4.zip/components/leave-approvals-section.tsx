"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { FileText, CheckCircle, XCircle } from "lucide-react"

export default function LeaveApprovalsSection() {
  const leaveRequests = [
    {
      id: 1,
      employee: "John Doe",
      type: "Paid Leave",
      from: "Jan 20, 2025",
      to: "Jan 22, 2025",
      status: "Pending",
      remarks: "Personal reasons",
    },
    {
      id: 2,
      employee: "Jane Smith",
      type: "Sick Leave",
      from: "Jan 18, 2025",
      to: "Jan 18, 2025",
      status: "Pending",
      remarks: "Medical",
    },
    {
      id: 3,
      employee: "Mike Johnson",
      type: "Paid Leave",
      from: "Jan 15, 2025",
      to: "Jan 16, 2025",
      status: "Approved",
      remarks: "Vacation",
    },
    {
      id: 4,
      employee: "Sarah Williams",
      type: "Unpaid Leave",
      from: "Jan 10, 2025",
      to: "Jan 12, 2025",
      status: "Rejected",
      remarks: "Personal",
    },
  ]

  const statusColors = {
    Pending: "bg-yellow-900 text-yellow-200",
    Approved: "bg-green-900 text-green-200",
    Rejected: "bg-red-900 text-red-200",
  }

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-white">Leave Approvals</h2>

      {/* Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-300">Pending Requests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-yellow-400">2</div>
            <p className="text-xs text-slate-400 mt-1">Awaiting approval</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-300">Approved</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-400">1</div>
            <p className="text-xs text-slate-400 mt-1">This month</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900 border-slate-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-slate-300">Rejected</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-400">1</div>
            <p className="text-xs text-slate-400 mt-1">This month</p>
          </CardContent>
        </Card>
      </div>

      {/* Requests Table */}
      <Card className="bg-slate-900 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Leave Requests
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {leaveRequests.map((request) => (
              <div
                key={request.id}
                className="p-4 bg-slate-800 rounded-lg border border-slate-700 hover:border-slate-600 transition"
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <p className="font-semibold text-white">{request.employee}</p>
                    <p className="text-sm text-slate-400">{request.type}</p>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${statusColors[request.status as keyof typeof statusColors]}`}
                  >
                    {request.status}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-4 text-sm mb-3">
                  <div>
                    <p className="text-slate-400">From</p>
                    <p className="text-white font-medium">{request.from}</p>
                  </div>
                  <div>
                    <p className="text-slate-400">To</p>
                    <p className="text-white font-medium">{request.to}</p>
                  </div>
                  <div>
                    <p className="text-slate-400">Remarks</p>
                    <p className="text-white font-medium">{request.remarks}</p>
                  </div>
                </div>

                {request.status === "Pending" && (
                  <div className="flex gap-2">
                    <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white">
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Approve
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-red-600 text-red-400 hover:bg-red-900 bg-transparent"
                    >
                      <XCircle className="w-4 h-4 mr-2" />
                      Reject
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
